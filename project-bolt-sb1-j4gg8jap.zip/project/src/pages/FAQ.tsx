import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, Search, HelpCircle, Shield, Truck, RotateCcw, Clock, CreditCard, Globe } from 'lucide-react';

const FAQ = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [openItems, setOpenItems] = useState<number[]>([]);

  const faqCategories = [
    {
      title: 'Orders & Shipping',
      icon: Truck,
      questions: [
        {
          question: 'How long does shipping take?',
          answer: 'Each watch is built to order, which takes 1-2 days - we\'ll notify you when your watch is built and ready to ship. Standard delivery then takes 7-14 business days, while express shipping (available for an additional fee) takes 3-5 business days. Shipping costs vary by location. You\'ll receive a tracking number once your order ships.'
        },
        {
          question: 'Do you ship internationally?',
          answer: 'Yes! We ship to over 150 countries worldwide. Shipping costs and delivery times may vary depending on your location. All international orders are fully insured and tracked.'
        },
        {
          question: 'Can I change or cancel my order?',
          answer: 'You can modify or cancel your order within 2 hours of placing it. After this time, your order enters our fulfillment process. Please contact our customer service team immediately if you need to make changes.'
        },
        {
          question: 'What payment methods do you accept?',
          answer: 'We accept all major credit cards (Visa, MasterCard, American Express), PayPal, Apple Pay, Google Pay, and bank transfers. All payments are processed securely through encrypted channels.'
        }
      ]
    },
    {
      title: 'Product Information',
      icon: Clock,
      questions: [
        {
          question: 'What movement do your watches use?',
          answer: 'Our watches feature high-quality Seiko movements manufactured in Japan, known for their precision and reliability. These Japanese movements are renowned in the horological world for their accuracy and durability.'
        },
        {
          question: 'Are the watches water-resistant?',
          answer: 'Yes, our watches have a water resistance rating of 3 ATM (30 meters), making them suitable for everyday wear and light splashes. However, they are not suitable for swimming or diving.'
        },
        {
          question: 'What materials are used in your watches?',
          answer: 'We use premium 904L stainless steel for cases and bracelets, sapphire crystal glass with anti-reflective coating, and high-quality leather for straps. All materials are carefully selected for durability and luxury appeal.'
        }
      ]
    },
    {
      title: 'Warranty & Returns',
      icon: Shield,
      questions: [
        {
          question: 'What warranty do you offer?',
          answer: 'All RDSSEIKO watches come with a 6-month workmanship warranty covering manufacturing defects that are our fault only. This includes movement issues, crown problems, and other manufacturing-related concerns. Customer damage, wear, or misuse is not covered.'
        },
        {
          question: 'What is your return policy?',
          answer: 'We offer a 4-day return policy for unworn watches in original condition with all packaging and documentation. Return shipping costs are the responsibility of the customer, except for defective items where we cover return shipping costs.'
        },
        {
          question: 'How do I claim warranty service?',
          answer: 'Contact our customer service team with your order number and description of the issue. We\'ll provide a prepaid shipping label and handle the repair or replacement process quickly and efficiently.'
        },
        {
          question: 'What if my watch arrives damaged?',
          answer: 'If your watch arrives damaged, please contact us immediately with photos of the damage. We do not accept returns for damaged watches as all items are carefully inspected before shipping.'
        }
      ]
    },
    {
      title: 'Care & Maintenance',
      icon: RotateCcw,
      questions: [
        {
          question: 'How do I care for my watch?',
          answer: 'Clean your watch regularly with a soft, dry cloth. Avoid exposure to extreme temperatures, strong magnetic fields, and chemicals. For automatic watches, wear regularly or use a watch winder to keep the movement active.'
        },
        {
          question: 'How often should I service my watch?',
          answer: 'We recommend professional servicing every 3-5 years to maintain optimal performance. However, if you notice any issues with timekeeping, crown function, or water resistance, contact us immediately.'
        },
        {
          question: 'Can I replace the strap or bracelet?',
          answer: 'Yes! Our watches use standard 20mm lugs, making them compatible with most aftermarket straps and bracelets. We also offer official RDSSEIKO replacement straps and bracelets.'
        },
        {
          question: 'My watch has stopped working, what should I do?',
          answer: 'For automatic watches, try winding the crown 20-30 times clockwise. If it still doesn\'t work, it may need servicing. Contact our support team - this is likely covered under warranty if the watch is less than 6 months old.'
        }
      ]
    },
    {
      title: 'Account & Support',
      icon: HelpCircle,
      questions: [
        {
          question: 'How do I create an account?',
          answer: 'Click the user icon in the top navigation and select "Sign Up". You\'ll need to provide your email address and create a password. Having an account allows you to track orders, save favorites, and access exclusive offers.'
        },
        {
          question: 'How can I contact customer support?',
          answer: 'You can reach us via WhatsApp at 07361837234, email us at info@rdsseiko.com, or use the contact form on our website. Our support team is available Monday-Friday, 9 AM-6 PM GMT.'
        },
        {
          question: 'Do you offer size adjustments?',
          answer: 'Our bracelets are adjustable from 14.5cm to 22cm. If you need additional links removed or added, contact us and we\'ll provide instructions or arrange for professional adjustment.'
        },
        {
          question: 'Can I get a certificate of authenticity?',
          answer: 'Every RDSSEIKO watch comes with a certificate of authenticity and warranty card. If you need additional documentation for insurance purposes, please contact our customer service team.'
        }
      ]
    }
  ];

  const allQuestions = faqCategories.flatMap((category, categoryIndex) =>
    category.questions.map((q, questionIndex) => ({
      ...q,
      categoryTitle: category.title,
      categoryIcon: category.icon,
      id: categoryIndex * 100 + questionIndex
    }))
  );

  const filteredQuestions = searchQuery
    ? allQuestions.filter(
        (item) =>
          item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.answer.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.categoryTitle.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : allQuestions;

  const toggleItem = (id: number) => {
    setOpenItems(prev =>
      prev.includes(id)
        ? prev.filter(item => item !== id)
        : [...prev, id]
    );
  };

  return (
    <div className="min-h-screen bg-navy pt-28">
      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-navy via-black to-navy">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <HelpCircle className="w-16 h-16 text-gold mx-auto mb-6" />
            <h1 className="text-4xl lg:text-5xl font-serif font-bold text-white mb-6">
              Frequently Asked Questions
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Find answers to common questions about our luxury timepieces, shipping, warranties, and more.
            </p>

            {/* Search Bar */}
            <div className="relative max-w-md mx-auto">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search FAQs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-gray-900/80 text-white placeholder-gray-400 rounded-lg pl-12 pr-4 py-4 border border-gray-700 focus:border-gold focus:outline-none backdrop-blur-sm"
              />
            </div>
          </motion.div>
        </div>
      </section>

      {/* FAQ Content */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {searchQuery ? (
            /* Search Results */
            <div className="space-y-4">
              <h2 className="text-2xl font-serif font-bold text-white mb-6">
                Search Results ({filteredQuestions.length})
              </h2>
              {filteredQuestions.length === 0 ? (
                <div className="text-center py-12">
                  <Search className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-white mb-2">No results found</h3>
                  <p className="text-gray-400">Try adjusting your search terms</p>
                </div>
              ) : (
                filteredQuestions.map((item) => (
                  <motion.div
                    key={item.id}
                    className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 overflow-hidden"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4 }}
                  >
                    <button
                      onClick={() => toggleItem(item.id)}
                      className="w-full p-6 text-left flex items-center justify-between hover:bg-gray-800/50 transition-colors duration-200"
                    >
                      <div className="flex items-center space-x-4">
                        <item.categoryIcon className="w-5 h-5 text-gold flex-shrink-0" />
                        <div>
                          <span className="text-xs text-gold font-semibold uppercase tracking-wide">
                            {item.categoryTitle}
                          </span>
                          <h3 className="text-lg font-semibold text-white mt-1">
                            {item.question}
                          </h3>
                        </div>
                      </div>
                      <ChevronDown
                        className={`w-5 h-5 text-gray-400 transition-transform duration-200 ${
                          openItems.includes(item.id) ? 'rotate-180' : ''
                        }`}
                      />
                    </button>
                    <AnimatePresence>
                      {openItems.includes(item.id) && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.3 }}
                          className="overflow-hidden"
                        >
                          <div className="px-6 pb-6 pt-0">
                            <p className="text-gray-300 leading-relaxed pl-9">
                              {item.answer}
                            </p>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                ))
              )}
            </div>
          ) : (
            /* Category View */
            <div className="space-y-12">
              {faqCategories.map((category, categoryIndex) => (
                <motion.div
                  key={categoryIndex}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: categoryIndex * 0.1 }}
                  viewport={{ once: true }}
                >
                  {/* Category Header */}
                  <div className="flex items-center space-x-3 mb-6">
                    <category.icon className="w-8 h-8 text-gold" />
                    <h2 className="text-2xl font-serif font-bold text-white">
                      {category.title}
                    </h2>
                  </div>

                  {/* Questions */}
                  <div className="space-y-4">
                    {category.questions.map((item, questionIndex) => {
                      const itemId = categoryIndex * 100 + questionIndex;
                      return (
                        <motion.div
                          key={questionIndex}
                          className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 overflow-hidden hover:border-gold/30 transition-colors duration-300"
                          initial={{ opacity: 0, x: -20 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.4, delay: questionIndex * 0.05 }}
                          viewport={{ once: true }}
                        >
                          <button
                            onClick={() => toggleItem(itemId)}
                            className="w-full p-6 text-left flex items-center justify-between hover:bg-gray-800/50 transition-colors duration-200"
                          >
                            <h3 className="text-lg font-semibold text-white pr-4">
                              {item.question}
                            </h3>
                            <ChevronDown
                              className={`w-5 h-5 text-gray-400 transition-transform duration-200 flex-shrink-0 ${
                                openItems.includes(itemId) ? 'rotate-180' : ''
                              }`}
                            />
                          </button>
                          <AnimatePresence>
                            {openItems.includes(itemId) && (
                              <motion.div
                                initial={{ height: 0, opacity: 0 }}
                                animate={{ height: 'auto', opacity: 1 }}
                                exit={{ height: 0, opacity: 0 }}
                                transition={{ duration: 0.3 }}
                                className="overflow-hidden"
                              >
                                <div className="px-6 pb-6 pt-0 border-t border-gray-800">
                                  <p className="text-gray-300 leading-relaxed mt-4">
                                    {item.answer}
                                  </p>
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </motion.div>
                      );
                    })}
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-gradient-to-r from-navy via-black to-navy">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-serif font-bold text-white mb-6">
              Still Have Questions?
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Our customer service team is here to help with any additional questions you may have.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.a
                href="https://wa.me/07361837234"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-gold text-black px-8 py-4 rounded-lg font-semibold hover:bg-yellow-400 transition-colors duration-200 flex items-center justify-center space-x-2"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Globe className="w-5 h-5" />
                <span>WhatsApp Support</span>
              </motion.a>
              
              <motion.a
                href="mailto:info@rdsseiko.com"
                className="border border-gray-600 text-white px-8 py-4 rounded-lg font-semibold hover:border-gold hover:text-gold transition-colors duration-200 flex items-center justify-center space-x-2"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <HelpCircle className="w-5 h-5" />
                <span>Email Us</span>
              </motion.a>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default FAQ;