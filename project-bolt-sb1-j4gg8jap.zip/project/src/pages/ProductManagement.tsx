import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Package, 
  Plus, 
  Edit, 
  Trash2, 
  Eye,
  Star,
  CheckCircle,
  AlertCircle,
  Search,
  Filter
} from 'lucide-react';
import { watches } from '../data/watches';
import { Watch } from '../types';

const ProductManagement = () => {
  const [products, setProducts] = useState<Watch[]>(() => {
    // Load products from localStorage or use default watches
    const storedProducts = localStorage.getItem('rdsseiko_products');
    return storedProducts ? JSON.parse(storedProducts) : watches;
  });
  const [isCreating, setIsCreating] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Watch | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  
  const [newProduct, setNewProduct] = useState({
    name: '',
    brand: 'RDSSEIKO',
    price: 0,
    category: 'mens' as const,
    collection: '',
    description: '',
    imageFile: null as File | null,
    imagePreview: '',
    specifications: {
      movement: '',
      caseMaterial: '',
      diameter: '',
      thickness: '',
      glass: '',
      luminova: '',
      crown: '',
      wristSize: '',
      lugs: '',
      bracelet: '',
      caseBack: '',
      waterResistance: '',
      dayDateFunction: '',
      warranty: '2 Years International'
    },
    inStock: true,
    isNew: false,
    isBestseller: false
  });

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.collection.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filterCategory === 'all' || product.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newProduct.name || !newProduct.collection || !newProduct.description) {
      setMessage({ type: 'error', text: 'Please fill in all required fields' });
      return;
    }

    // For demo purposes, use a placeholder image if no file uploaded
    const imageUrl = newProduct.imagePreview || '/placeholder-watch.jpg';

    const product: Watch = {
      ...newProduct,
      id: Date.now().toString(),
      image: imageUrl,
      images: [imageUrl],
      rating: 5.0,
      reviewCount: 0
    };

    const updatedProducts = [...products, product];
    setProducts(updatedProducts);
    // Save to localStorage
    localStorage.setItem('rdsseiko_products', JSON.stringify(updatedProducts));
    
    setNewProduct({
      name: '',
      brand: 'RDSSEIKO',
      price: 0,
      category: 'mens',
      collection: '',
      description: '',
      imageFile: null,
      imagePreview: '',
      specifications: {
        movement: '',
        caseMaterial: '',
        diameter: '',
        thickness: '',
        glass: '',
        luminova: '',
        crown: '',
        wristSize: '',
        lugs: '',
        bracelet: '',
        caseBack: '',
        waterResistance: '',
        dayDateFunction: '',
        warranty: '6 Month Workmanship Warranty'
      },
      inStock: true,
      isNew: false,
      isBestseller: false
    });
    setIsCreating(false);
    setMessage({ type: 'success', text: 'Product created successfully!' });
    setTimeout(() => setMessage(null), 3000);
  };

  const handleEditProduct = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!editingProduct || !newProduct.name || !newProduct.collection || !newProduct.description) {
      setMessage({ type: 'error', text: 'Please fill in all required fields' });
      return;
    }

    // Use existing image if no new image uploaded
    const imageUrl = newProduct.imagePreview || editingProduct.image;

    const updatedProduct: Watch = {
      ...editingProduct,
      ...newProduct,
      image: imageUrl,
      images: [imageUrl]
    };

    const updatedProducts = products.map(p => p.id === editingProduct.id ? updatedProduct : p);
    setProducts(updatedProducts);
    // Save to localStorage
    localStorage.setItem('rdsseiko_products', JSON.stringify(updatedProducts));
    
    setEditingProduct(null);
    setNewProduct({
      name: '',
      brand: 'RDSSEIKO',
      price: 0,
      category: 'mens',
      collection: '',
      description: '',
      imageFile: null,
      imagePreview: '',
      specifications: {
        movement: '',
        caseMaterial: '',
        diameter: '',
        thickness: '',
        glass: '',
        luminova: '',
        crown: '',
        wristSize: '',
        lugs: '',
        bracelet: '',
        caseBack: '',
        waterResistance: '',
        dayDateFunction: '',
        warranty: '6 Month Workmanship Warranty'
      },
      inStock: true,
      isNew: false,
      isBestseller: false
    });
    setIsEditing(false);
    setMessage({ type: 'success', text: 'Product updated successfully!' });
    setTimeout(() => setMessage(null), 3000);
  };

  const startEditProduct = (product: Watch) => {
    setEditingProduct(product);
    setNewProduct({
      name: product.name,
      brand: product.brand,
      price: product.price,
      category: product.category,
      collection: product.collection,
      description: product.description,
      imageFile: null,
      imagePreview: product.image,
      specifications: product.specifications,
      inStock: product.inStock,
      isNew: product.isNew || false,
      isBestseller: product.isBestseller || false
    });
    setIsEditing(true);
  };

  const cancelEdit = () => {
    setIsEditing(false);
    setEditingProduct(null);
    setNewProduct({
      name: '',
      brand: 'RDSSEIKO',
      price: 0,
      category: 'mens',
      collection: '',
      description: '',
      imageFile: null,
      imagePreview: '',
      specifications: {
        movement: '',
        caseMaterial: '',
        diameter: '',
        thickness: '',
        glass: '',
        luminova: '',
        crown: '',
        wristSize: '',
        lugs: '',
        bracelet: '',
        caseBack: '',
        waterResistance: '',
        dayDateFunction: '',
        warranty: '6 Month Workmanship Warranty'
      },
      inStock: true,
      isNew: false,
      isBestseller: false
    });
  };
  const handleImageUpload = (file: File) => {
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageUrl = e.target?.result as string;
        setNewProduct({ ...newProduct, imageFile: file, imagePreview: imageUrl });
      };
      reader.readAsDataURL(file);
    } else {
      setMessage({ type: 'error', text: 'Please upload a valid image file' });
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleImageUpload(files[0]);
    }
  };

  const handleDeleteProduct = (id: string) => {
    if (confirm('Are you sure you want to delete this product?')) {
      const updatedProducts = products.filter(product => product.id !== id);
      setProducts(updatedProducts);
      // Save to localStorage
      localStorage.setItem('rdsseiko_products', JSON.stringify(updatedProducts));
      setMessage({ type: 'success', text: 'Product deleted successfully!' });
      setTimeout(() => setMessage(null), 3000);
    }
  };

  const toggleProductStatus = (id: string, field: 'inStock' | 'isNew' | 'isBestseller') => {
    // Prevent event bubbling when clicking status toggles
    event?.stopPropagation();
    const updatedProducts = products.map(product => 
      product.id === id 
        ? { ...product, [field]: !product[field] }
        : product
    );
    setProducts(updatedProducts);
    // Save to localStorage
    localStorage.setItem('rdsseiko_products', JSON.stringify(updatedProducts));
  };

  return (
    <div className="min-h-screen bg-navy pt-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          className="mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Link
            to="/admin"
            className="flex items-center space-x-2 text-gray-400 hover:text-gold transition-colors mb-4"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Admin Dashboard</span>
          </Link>
          
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <Package className="w-8 h-8 text-gold" />
                <h1 className="text-3xl lg:text-4xl font-serif font-bold text-white">
                  Product Management
                </h1>
              </div>
              <p className="text-gray-400">
                Add, edit, or remove products from your catalog
              </p>
            </div>
            
            <motion.button
              onClick={() => setIsCreating(true)}
              className="bg-gold text-black px-6 py-3 rounded-lg font-semibold hover:bg-yellow-400 transition-colors flex items-center space-x-2"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Plus className="w-5 h-5" />
              <span>Add Product</span>
            </motion.button>
          </div>
        </motion.div>

        {/* Message */}
        {message && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex items-center space-x-2 p-4 rounded-lg mb-6 ${
              message.type === 'success' 
                ? 'bg-green-900/50 border border-green-700 text-green-300' 
                : 'bg-red-900/50 border border-red-700 text-red-300'
            }`}
          >
            {message.type === 'success' ? (
              <CheckCircle className="w-5 h-5" />
            ) : (
              <AlertCircle className="w-5 h-5" />
            )}
            <span>{message.text}</span>
          </motion.div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {[
            {
              title: 'Total Products',
              value: products.length,
              icon: Package,
              color: 'text-blue-400',
              bgColor: 'bg-blue-400/10'
            },
            {
              title: 'In Stock',
              value: products.filter(p => p.inStock).length,
              icon: CheckCircle,
              color: 'text-green-400',
              bgColor: 'bg-green-400/10'
            },
            {
              title: 'New Products',
              value: products.filter(p => p.isNew).length,
              icon: Star,
              color: 'text-gold',
              bgColor: 'bg-gold/10'
            },
            {
              title: 'Bestsellers',
              value: products.filter(p => p.isBestseller).length,
              icon: Star,
              color: 'text-purple-400',
              bgColor: 'bg-purple-400/10'
            }
          ].map((stat, index) => (
            <motion.div
              key={index}
              className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
            >
              <div className={`p-3 rounded-lg ${stat.bgColor} mb-4 w-fit`}>
                <stat.icon className={`w-6 h-6 ${stat.color}`} />
              </div>
              <h3 className="text-2xl font-bold text-white mb-1">{stat.value}</h3>
              <p className="text-gray-400 text-sm">{stat.title}</p>
            </motion.div>
          ))}
        </div>

        {/* Filters */}
        <motion.div
          className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-gray-900 text-white pl-10 pr-4 py-3 rounded-lg border border-gray-700 focus:border-gold focus:outline-none"
              />
            </div>
            
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="bg-gray-900 text-white px-4 py-3 rounded-lg border border-gray-700 focus:border-gold focus:outline-none"
            >
              <option value="all">All Categories</option>
              <option value="mens">Men's Watches</option>
            </select>
          </div>
        </motion.div>

        {/* Create/Edit Product Modal */}
        {(isCreating || isEditing) && (
          <motion.div
            className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <motion.div
              className="bg-navy border border-gray-800 rounded-xl p-8 max-w-4xl w-full max-h-[90vh] overflow-y-auto"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-serif font-bold text-white">
                  {isEditing ? 'Edit Product' : 'Add New Product'}
                </h2>
                <button
                  onClick={() => {
                    if (isEditing) {
                      cancelEdit();
                    } else {
                      setIsCreating(false);
                    }
                  }}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  ×
                </button>
              </div>

              <form onSubmit={isEditing ? handleEditProduct : handleCreateProduct} className="space-y-6">
                  <div>
                    <label className="block text-white font-semibold mb-2">Product Name *</label>
                    <input
                      type="text"
                      value={newProduct.name}
                      onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                      className="w-full bg-gray-900 text-white rounded-lg px-4 py-3 border border-gray-700 focus:border-gold focus:outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-white font-semibold mb-2">Price ($) *</label>
                    <input
                      type="number"
                      value={newProduct.price}
                      onChange={(e) => setNewProduct({ ...newProduct, price: Number(e.target.value) })}
                      className="w-full bg-gray-900 text-white rounded-lg px-4 py-3 border border-gray-700 focus:border-gold focus:outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-white font-semibold mb-2">Collection *</label>
                    <input
                      type="text"
                      value={newProduct.collection}
                      onChange={(e) => setNewProduct({ ...newProduct, collection: e.target.value })}
                      className="w-full bg-gray-900 text-white rounded-lg px-4 py-3 border border-gray-700 focus:border-gold focus:outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-white font-semibold mb-2">Product Image</label>
                    <div
                      onDragOver={handleDragOver}
                      onDrop={handleDrop}
                      className="relative w-full bg-gray-900 border-2 border-dashed border-gray-700 rounded-lg p-8 text-center hover:border-gold transition-colors duration-200"
                    >
                      {newProduct.imagePreview ? (
                        <div className="space-y-4">
                          <img
                            src={newProduct.imagePreview}
                            alt="Product preview"
                            className="w-32 h-32 object-cover rounded-lg mx-auto"
                          />
                          <p className="text-gray-400 text-sm">Drag & drop a new image to replace</p>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          <div className="w-16 h-16 bg-gray-800 rounded-lg mx-auto flex items-center justify-center">
                            <svg className="w-8 h-8 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                            </svg>
                          </div>
                          <div>
                            <p className="text-white font-semibold">Drag & drop your image here</p>
                            <p className="text-gray-400 text-sm">or click to browse</p>
                          </div>
                        </div>
                      )}
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) handleImageUpload(file);
                        }}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer pointer-events-auto"
                      />
                    </div>
                  </div>

                <div>
                  <label className="block text-white font-semibold mb-2">Description *</label>
                  <textarea
                    value={newProduct.description}
                    onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                    className="w-full bg-gray-900 text-white rounded-lg px-4 py-3 border border-gray-700 focus:border-gold focus:outline-none h-24"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={newProduct.inStock}
                      onChange={(e) => setNewProduct({ ...newProduct, inStock: e.target.checked })}
                      className="rounded border-gray-700 text-gold focus:ring-gold"
                    />
                    <span className="text-white">In Stock</span>
                  </label>

                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={newProduct.isNew}
                      onChange={(e) => setNewProduct({ ...newProduct, isNew: e.target.checked })}
                      className="rounded border-gray-700 text-gold focus:ring-gold"
                    />
                    <span className="text-white">New Product</span>
                  </label>

                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={newProduct.isBestseller}
                      onChange={(e) => setNewProduct({ ...newProduct, isBestseller: e.target.checked })}
                      className="rounded border-gray-700 text-gold focus:ring-gold"
                    />
                    <span className="text-white">Bestseller</span>
                  </label>
                </div>

                <div className="flex space-x-4">
                  <button
                    type="submit"
                    className="flex-1 bg-gold text-black py-3 rounded-lg font-semibold hover:bg-yellow-400 transition-colors"
                  >
                    {isEditing ? 'Update Product' : 'Create Product'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (isEditing) {
                        cancelEdit();
                      } else {
                        setIsCreating(false);
                      }
                    }}
                    className="flex-1 border border-gray-600 text-white py-3 rounded-lg font-semibold hover:border-gold hover:text-gold transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}

        {/* Products List */}
        <motion.div
          className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <h2 className="text-xl font-serif font-bold text-white mb-6">
            Products ({filteredProducts.length})
          </h2>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-800">
                  <th className="text-left text-gray-400 font-semibold py-3">Product</th>
                  <th className="text-left text-gray-400 font-semibold py-3">Price</th>
                  <th className="text-left text-gray-400 font-semibold py-3">Collection</th>
                  <th className="text-left text-gray-400 font-semibold py-3">Status</th>
                  <th className="text-left text-gray-400 font-semibold py-3">Badges</th>
                  <th className="text-left text-gray-400 font-semibold py-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredProducts.map((product) => (
                  <tr key={product.id} className="border-b border-gray-800/50 hover:bg-gray-800/30 transition-colors cursor-pointer">
                    <td className="py-4">
                      <div className="flex items-center space-x-3">
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-12 h-12 object-cover rounded-lg"
                        />
                        <div>
                          <div className="text-white font-semibold">{product.name}</div>
                          <div className="text-gray-400 text-sm">{product.brand}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 text-gold font-semibold">${product.price.toLocaleString()}</td>
                    <td className="py-4 text-gray-300">{product.collection}</td>
                    <td className="py-4">
                      <button
                        onClick={() => toggleProductStatus(product.id, 'inStock')}
                        className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          product.inStock 
                            ? 'bg-green-900/50 text-green-300' 
                            : 'bg-red-900/50 text-red-300'
                        }`}
                      >
                        {product.inStock ? 'In Stock' : 'Out of Stock'}
                      </button>
                    </td>
                    <td className="py-4">
                      <div className="flex space-x-2">
                        {product.isNew && (
                          <button
                            onClick={() => toggleProductStatus(product.id, 'isNew')}
                            className="bg-gold/20 text-gold px-2 py-1 rounded text-xs"
                          >
                            NEW
                          </button>
                        )}
                        {product.isBestseller && (
                          <button
                            onClick={() => toggleProductStatus(product.id, 'isBestseller')}
                            className="bg-purple-900/50 text-purple-300 px-2 py-1 rounded text-xs"
                          >
                            BESTSELLER
                          </button>
                        )}
                      </div>
                    </td>
                    <td className="py-4">
                      <div className="flex items-center space-x-2" onClick={(e) => e.stopPropagation()}>
                        <Link
                          to={`/product/${product.id}`}
                          className="text-blue-400 hover:text-blue-300 transition-colors"
                        >
                          <Eye className="w-4 h-4" />
                        </Link>
                        <button
                          onClick={() => startEditProduct(product)}
                          className="text-yellow-400 hover:text-yellow-300 transition-colors"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteProduct(product.id)}
                          className="text-red-400 hover:text-red-300 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default ProductManagement;