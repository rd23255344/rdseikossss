import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Phone, 
  Mail, 
  MessageCircle, 
  Clock, 
  MapPin, 
  Send,
  CheckCircle,
  AlertCircle,
  Heart,
  Shield,
  Headphones,
  Globe
} from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    orderNumber: '',
    message: '',
    priority: 'normal'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Send contact form data to musa20100@outlook.com
    try {
      const contactData = {
        to: 'musa20100@outlook.com',
        subject: `RDSSEIKO Contact Form: ${formData.subject}`,
        body: `New contact form submission:
        
Name: ${formData.name}
Email: ${formData.email}
Subject: ${formData.subject}
Order Number: ${formData.orderNumber || 'N/A'}
Priority: ${formData.priority}

Message:
${formData.message}

Submitted: ${new Date().toLocaleString()}`
      };
      
      console.log('Contact form data to send:', contactData);
      
      // In production, this would send to your email service
      // For now, we'll simulate the submission
    } catch (error) {
      console.error('Failed to send contact form:', error);
    }

    setTimeout(() => {
      setMessage({ 
        type: 'success', 
        text: 'Thank you! Your message has been sent. We\'ll respond within 24 hours.' 
      });
      setFormData({
        name: '',
        email: '',
        subject: '',
        orderNumber: '',
        message: '',
        priority: 'normal'
      });
      setIsSubmitting(false);
      
      // Clear success message after 5 seconds
      setTimeout(() => setMessage(null), 5000);
    }, 2000);
  };

  const contactMethods = [
    {
      icon: MessageCircle,
      title: 'WhatsApp Support',
      description: 'Fastest response - usually within 1 hour',
      contact: '07361837234',
      action: 'Chat Now',
      link: 'https://wa.me/07361837234',
      color: 'text-green-400',
      bgColor: 'bg-green-400/10',
      available: '24/7 Available'
    },
    {
      icon: Mail,
      title: 'Email Support',
      description: 'Detailed inquiries and order issues',
      contact: 'info@rdsseiko.com',
      action: 'Send Email',
      link: 'mailto:info@rdsseiko.com',
      color: 'text-blue-400',
      bgColor: 'bg-blue-400/10',
      available: 'Response within 24 hours'
    }
  ];

  const supportTopics = [
    {
      icon: Shield,
      title: 'Warranty Claims',
      description: 'Manufacturing defects and workmanship issues',
      response: 'Within 2 hours'
    },
    {
      icon: MessageCircle,
      title: 'Order Status',
      description: 'Track your order and delivery updates',
      response: 'Within 1 hour'
    },
    {
      icon: Heart,
      title: 'Product Questions',
      description: 'Specifications, compatibility, and features',
      response: 'Within 4 hours'
    },
    {
      icon: Globe,
      title: 'Returns & Exchanges',
      description: 'Return process and exchange requests',
      response: 'Within 2 hours'
    }
  ];

  return (
    <div className="min-h-screen bg-navy pt-28">
      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-navy via-black to-navy">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <Headphones className="w-16 h-16 text-gold mx-auto mb-6" />
            <h1 className="text-4xl lg:text-5xl font-serif font-bold text-white mb-6">
              Contact Support
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              We're here to help with any questions about your RDSSEIKO timepiece. 
              Our expert support team is ready to assist you.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Contact Methods */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-serif font-bold text-white mb-6">
              Get In Touch
            </h2>
            <p className="text-xl text-gray-300">
              Choose your preferred way to contact our support team
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {contactMethods.map((method, index) => (
              <motion.div
                key={index}
                className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-8 text-center hover:border-gold/30 transition-colors duration-300"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -5 }}
              >
                <div className={`p-4 rounded-full ${method.bgColor} w-fit mx-auto mb-6`}>
                  <method.icon className={`w-8 h-8 ${method.color}`} />
                </div>
                
                <h3 className="text-xl font-serif font-bold text-white mb-3">
                  {method.title}
                </h3>
                
                <p className="text-gray-300 mb-4">
                  {method.description}
                </p>
                
                <div className="text-gold font-semibold mb-4">
                  {method.contact}
                </div>
                
                <div className="text-sm text-gray-400 mb-6">
                  {method.available}
                </div>
                
                <motion.a
                  href={method.link}
                  target={method.link.startsWith('http') ? '_blank' : undefined}
                  rel={method.link.startsWith('http') ? 'noopener noreferrer' : undefined}
                  className="bg-gold text-black px-6 py-3 rounded-lg font-semibold hover:bg-yellow-400 transition-colors duration-200 inline-block"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {method.action}
                </motion.a>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Support Topics */}
      <section className="py-16 bg-gradient-to-b from-black to-navy">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-serif font-bold text-white mb-6">
              What Can We Help You With?
            </h2>
            <p className="text-xl text-gray-300">
              Our support team specializes in these areas
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {supportTopics.map((topic, index) => (
              <motion.div
                key={index}
                className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6 text-center"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -5 }}
              >
                <topic.icon className="w-8 h-8 text-gold mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">
                  {topic.title}
                </h3>
                <p className="text-gray-300 text-sm mb-3">
                  {topic.description}
                </p>
                <div className="text-gold text-xs font-semibold">
                  Response: {topic.response}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-serif font-bold text-white mb-6">
              Send Us a Message
            </h2>
            <p className="text-xl text-gray-300">
              Fill out the form below and we'll get back to you within 24 hours
            </p>
          </motion.div>

          <motion.div
            className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-8"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            {/* Message */}
            {message && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex items-center space-x-2 p-4 rounded-lg mb-6 ${
                  message.type === 'success' 
                    ? 'bg-green-900/50 border border-green-700 text-green-300' 
                    : 'bg-red-900/50 border border-red-700 text-red-300'
                }`}
              >
                {message.type === 'success' ? (
                  <CheckCircle className="w-5 h-5" />
                ) : (
                  <AlertCircle className="w-5 h-5" />
                )}
                <span>{message.text}</span>
              </motion.div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-white font-semibold mb-2">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-gray-900 text-white rounded-lg px-4 py-3 border border-gray-700 focus:border-gold focus:outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block text-white font-semibold mb-2">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full bg-gray-900 text-white rounded-lg px-4 py-3 border border-gray-700 focus:border-gold focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-white font-semibold mb-2">
                    Subject *
                  </label>
                  <select
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    className="w-full bg-gray-900 text-white rounded-lg px-4 py-3 border border-gray-700 focus:border-gold focus:outline-none"
                    required
                  >
                    <option value="">Select a subject</option>
                    <option value="warranty">Warranty Claim</option>
                    <option value="order">Order Status</option>
                    <option value="product">Product Question</option>
                    <option value="return">Return/Exchange</option>
                    <option value="shipping">Shipping Inquiry</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-white font-semibold mb-2">
                    Order Number (if applicable)
                  </label>
                  <input
                    type="text"
                    value={formData.orderNumber}
                    onChange={(e) => setFormData({ ...formData, orderNumber: e.target.value })}
                    className="w-full bg-gray-900 text-white rounded-lg px-4 py-3 border border-gray-700 focus:border-gold focus:outline-none"
                    placeholder="e.g., RDS-2025-001"
                  />
                </div>
              </div>

              <div>
                <label className="block text-white font-semibold mb-2">
                  Priority Level
                </label>
                <div className="flex space-x-4">
                  {[
                    { value: 'low', label: 'Low', color: 'text-green-400' },
                    { value: 'normal', label: 'Normal', color: 'text-blue-400' },
                    { value: 'high', label: 'High', color: 'text-orange-400' },
                    { value: 'urgent', label: 'Urgent', color: 'text-red-400' }
                  ].map((priority) => (
                    <label key={priority.value} className="flex items-center space-x-2">
                      <input
                        type="radio"
                        name="priority"
                        value={priority.value}
                        checked={formData.priority === priority.value}
                        onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                        className="text-gold focus:ring-gold"
                      />
                      <span className={`${priority.color} font-semibold`}>
                        {priority.label}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-white font-semibold mb-2">
                  Message *
                </label>
                <textarea
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full bg-gray-900 text-white rounded-lg px-4 py-3 border border-gray-700 focus:border-gold focus:outline-none h-32"
                  placeholder="Please describe your inquiry in detail..."
                  required
                />
              </div>

              <motion.button
                type="submit"
                className="w-full bg-gold text-black py-4 rounded-lg font-semibold hover:bg-yellow-400 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                    <span>Sending Message...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    <span>Send Message</span>
                  </>
                )}
              </motion.button>
            </form>
          </motion.div>
        </div>
      </section>

      {/* Business Hours & Location */}
      <section className="py-16 bg-gradient-to-r from-navy via-black to-navy">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {/* Business Hours */}
            <motion.div
              className="text-center md:text-left"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <Clock className="w-12 h-12 text-gold mx-auto md:mx-0 mb-6" />
              <h3 className="text-2xl font-serif font-bold text-white mb-6">
                Business Hours
              </h3>
              <div className="space-y-3 text-gray-300">
                <div className="flex justify-between items-center">
                  <span>Monday - Friday:</span>
                  <span className="text-gold font-semibold">9:00 AM - 6:00 PM GMT</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Saturday:</span>
                  <span className="text-gold font-semibold">10:00 AM - 4:00 PM GMT</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Sunday:</span>
                  <span className="text-gold font-semibold">11:00 AM - 12:00 PM GMT</span>
                </div>
                <div className="pt-4 border-t border-gray-800">
                  <div className="flex justify-between items-center">
                    <span>WhatsApp Support:</span>
                    <span className="text-green-400 font-semibold">24/7 Available</span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Location */}
            <motion.div
              className="text-center md:text-left"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <MapPin className="w-12 h-12 text-gold mx-auto md:mx-0 mb-6" />
              <h3 className="text-2xl font-serif font-bold text-white mb-6">
                Our Location
              </h3>
              <div className="space-y-3 text-gray-300">
                <p className="text-lg">
                  <span className="text-gold font-semibold">RDSSEIKO</span><br />
                  London, United Kingdom
                </p>
                <p className="text-sm">
                  Family-owned luxury watch business<br />
                  Serving customers worldwide since 1950
                </p>
                <div className="pt-4 border-t border-gray-800">
                  <p className="text-gold font-semibold">
                    🇹🇷 Turkey → 🇩🇪 Germany → 🇬🇧 London
                  </p>
                  <p className="text-sm text-gray-400">
                    Three generations of horological excellence
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* FAQ Link */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-serif font-bold text-white mb-6">
              Need Quick Answers?
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Check our FAQ section for instant answers to common questions
            </p>
            
            <motion.a
              href="/faq"
              className="bg-gold text-black px-8 py-4 rounded-lg font-semibold hover:bg-yellow-400 transition-colors duration-200 inline-flex items-center space-x-2"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <MessageCircle className="w-5 h-5" />
              <span>View FAQ</span>
            </motion.a>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Contact;