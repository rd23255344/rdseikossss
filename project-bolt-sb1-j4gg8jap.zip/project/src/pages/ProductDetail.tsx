import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Heart, 
  ShoppingBag, 
  Star, 
  ArrowLeft, 
  Plus, 
  Minus,
  ZoomIn,
  Shield,
  Truck,
  RotateCcw
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatPrice } from '../utils/currency';
import { getStripeProduct } from '../data/watches';
import CheckoutButton from '../components/Checkout/CheckoutButton';

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { state, dispatch } = useApp();
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [isZoomed, setIsZoomed] = useState(false);
  const [watch, setWatch] = useState<any>(null);

  // Load watch from localStorage
  useEffect(() => {
    const storedProducts = localStorage.getItem('rdsseiko_products');
    const products = storedProducts ? JSON.parse(storedProducts) : [];
    const foundWatch = products.find((w: any) => w.id === id);
    setWatch(foundWatch);
  }, [id]);

  useEffect(() => {
    if (!watch) {
      navigate('/catalog');
    }
  }, [watch, navigate]);

  if (!watch) {
    return null;
  }

  const isInWishlist = state.wishlist.includes(watch.id);
  const stripeProduct = getStripeProduct(watch.id);

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      dispatch({ type: 'ADD_TO_CART', payload: watch });
    }
  };

  const handleToggleWishlist = () => {
    dispatch({ type: 'TOGGLE_WISHLIST', payload: watch.id });
  };

  return (
    <div className="min-h-screen bg-navy pt-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <motion.button
          onClick={() => navigate(-1)}
          className="flex items-center space-x-2 text-gray-400 hover:text-gold transition-colors mb-8"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Collection</span>
        </motion.button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Images */}
          <motion.div
            className="space-y-4"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            {/* Main Image */}
            <div className="relative aspect-square bg-black/50 rounded-xl overflow-hidden border border-gray-800">
              <motion.img
                src={watch.images[selectedImage]}
                alt={watch.name}
                className={`w-full h-full object-cover transition-transform duration-500 ${
                  isZoomed ? 'scale-150 cursor-zoom-out' : 'cursor-zoom-in'
                }`}
                onClick={() => setIsZoomed(!isZoomed)}
                whileHover={{ scale: isZoomed ? 1.5 : 1.05 }}
              />
              
              {/* Zoom Icon */}
              <div className="absolute top-4 right-4 bg-black/50 backdrop-blur-sm rounded-full p-2">
                <ZoomIn className="w-5 h-5 text-white" />
              </div>

              {/* Badges */}
              <div className="absolute top-4 left-4 flex flex-col gap-2">
                {watch.isNew && (
                  <span className="bg-gold text-black px-3 py-1 rounded-full text-xs font-bold">
                    NEW
                  </span>
                )}
                {watch.isBestseller && (
                  <span className="bg-silver text-black px-3 py-1 rounded-full text-xs font-bold">
                    BESTSELLER
                  </span>
                )}
              </div>
            </div>

            {/* Thumbnail Images */}
            <div className="flex space-x-4">
              {watch.images.map((image, index) => (
                <motion.button
                  key={index}
                  onClick={() => setSelectedImage(index)}
                  className={`w-20 h-20 rounded-lg overflow-hidden border-2 ${
                    selectedImage === index ? 'border-gold' : 'border-gray-700'
                  }`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <img
                    src={image}
                    alt={`${watch.name} ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </motion.button>
              ))}
            </div>
          </motion.div>

          {/* Product Info */}
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            {/* Header */}
            <div>
              <p className="text-gold text-sm font-semibold mb-2">{watch.collection}</p>
              <h1 className="text-3xl lg:text-4xl font-serif font-bold text-white mb-4">
                {watch.name}
              </h1>
              
              {/* Rating */}
              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-5 h-5 ${
                        i < Math.floor(watch.rating) 
                          ? 'text-gold fill-gold' 
                          : 'text-gray-600'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-gray-400">
                  {watch.rating} ({watch.reviewCount} reviews)
                </span>
              </div>

              {/* Price */}
              <div className="flex items-center gap-4 mb-6">
                <div className="text-3xl font-bold text-gold">
                  {formatPrice(watch.price, state.currency)}
                </div>
                {watch.originalPrice && (
                  <div className="text-xl text-gray-400 line-through">
                    {formatPrice(watch.originalPrice, state.currency)}
                  </div>
                )}
              </div>
            </div>

            {/* Description */}
            <div className="prose prose-invert">
              <p className="text-gray-300 leading-relaxed">
                {watch.description}
              </p>
            </div>

            {/* Specifications */}
            <div className="bg-black/50 rounded-xl p-6 border border-gray-800">
              <h3 className="text-lg font-semibold text-gold mb-4">Specifications</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div className="space-y-3">
                  <div>
                    <span className="text-gray-400">Movement:</span>
                    <span className="text-white ml-2">{watch.specifications.movement}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Case Material:</span>
                    <span className="text-white ml-2">{watch.specifications.caseMaterial}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Diameter:</span>
                    <span className="text-white ml-2">{watch.specifications.diameter}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Thickness:</span>
                    <span className="text-white ml-2">{watch.specifications.thickness}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Glass:</span>
                    <span className="text-white ml-2">{watch.specifications.glass}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Luminova:</span>
                    <span className="text-white ml-2">{watch.specifications.luminova}</span>
                  </div>
                </div>
                <div className="space-y-3">
                  <div>
                    <span className="text-gray-400">Crown:</span>
                    <span className="text-white ml-2">{watch.specifications.crown}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Wrist Size:</span>
                    <span className="text-white ml-2">{watch.specifications.wristSize}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Lugs:</span>
                    <span className="text-white ml-2">{watch.specifications.lugs}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Bracelet:</span>
                    <span className="text-white ml-2">{watch.specifications.bracelet}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Case Back:</span>
                    <span className="text-white ml-2">{watch.specifications.caseBack}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Water Resistance:</span>
                    <span className="text-white ml-2">{watch.specifications.waterResistance}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Day-Date Function:</span>
                    <span className="text-white ml-2">{watch.specifications.dayDateFunction}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quantity & Actions */}
            <div className="space-y-4">
              {/* Quantity Selector */}
              <div className="flex items-center space-x-4">
                <span className="text-white font-semibold">Quantity:</span>
                <div className="flex items-center bg-gray-800 rounded-lg">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-2 text-white hover:text-gold transition-colors"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="px-4 py-2 text-white font-semibold">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="p-2 text-white hover:text-gold transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-4">
                <motion.button
                  onClick={handleAddToCart}
                  className="flex-1 bg-gray-700 text-white py-4 px-6 rounded-lg font-semibold hover:bg-gray-600 transition-colors duration-200 flex items-center justify-center space-x-2"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  disabled={!watch.inStock}
                >
                  <ShoppingBag className="w-5 h-5" />
                  <span>{watch.inStock ? 'Add to Cart' : 'Out of Stock'}</span>
                </motion.button>

                {stripeProduct && (
                  <CheckoutButton 
                    product={stripeProduct} 
                    className="flex-1 py-4 px-6"
                  />
                )}

                <motion.button
                  onClick={handleToggleWishlist}
                  className={`px-6 py-4 rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center space-x-2 ${
                    isInWishlist
                      ? 'bg-gold text-black hover:bg-yellow-400'
                      : 'border border-gray-600 text-white hover:border-gold hover:text-gold'
                  }`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Heart className={`w-5 h-5 ${isInWishlist ? 'fill-current' : ''}`} />
                  <span>{isInWishlist ? 'In Wishlist' : 'Add to Wishlist'}</span>
                </motion.button>
              </div>
            </div>

            {/* Features */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-6 border-t border-gray-800">
              <div className="flex items-center space-x-3 text-gray-300">
                <Shield className="w-5 h-5 text-gold" />
                <span className="text-sm">6 Month Workmanship Warranty</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-300">
                <Truck className="w-5 h-5 text-gold" />
                <span className="text-sm">Free Shipping</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-300">
                <RotateCcw className="w-5 h-5 text-gold" />
                <span className="text-sm">30-Day Returns</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;