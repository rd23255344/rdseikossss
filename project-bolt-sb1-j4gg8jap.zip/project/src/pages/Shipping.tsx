import React from 'react';
import { motion } from 'framer-motion';
import { Truck, Clock, Shield, Package, MapPin, Phone, Mail } from 'lucide-react';

const Shipping = () => {
  const shippingMethods = [
    {
      name: 'Royal Mail 1st Class',
      price: '',
      time: '1-2 business days',
      description: 'Standard delivery within the UK',
      icon: Package
    },
    {
      name: 'Royal Mail Special Delivery',
      price: '',
      time: 'Next working day by 1pm',
      description: 'Guaranteed next day delivery with tracking',
      icon: Shield
    },
    {
      name: 'Royal Mail International Standard',
      price: '',
      time: '5-7 business days',
      description: 'International delivery to most countries',
      icon: MapPin
    },
    {
      name: 'Royal Mail International Tracked',
      price: '',
      time: '3-5 business days',
      description: 'Express international delivery with full tracking',
      icon: Truck
    }
  ];

  const processingSteps = [
    {
      step: 1,
      title: 'Order Confirmation',
      description: 'Your order is received and confirmed within 1 hour',
      time: '0-1 hours'
    },
    {
      step: 2,
      title: 'Watch Assembly',
      description: 'Each watch is built to order with precision craftsmanship',
      time: '1-2 days'
    },
    {
      step: 3,
      title: 'Quality Control',
      description: 'Rigorous testing and inspection before packaging',
      time: '2-4 hours'
    },
    {
      step: 4,
      title: 'Secure Packaging',
      description: 'Professional packaging with luxury presentation box',
      time: '1-2 hours'
    },
    {
      step: 5,
      title: 'Royal Mail Dispatch',
      description: 'Handed to Royal Mail with tracking information sent to you',
      time: 'Same day'
    }
  ];

  return (
    <div className="min-h-screen bg-navy pt-28">
      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-navy via-black to-navy">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <Truck className="w-16 h-16 text-gold mx-auto mb-6" />
            <h1 className="text-4xl lg:text-5xl font-serif font-bold text-white mb-6">
              Shipping Information
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Fast, secure delivery via Royal Mail with full tracking and insurance
            </p>
          </motion.div>
        </div>
      </section>

      {/* Processing Time Banner */}
      <section className="py-8 bg-gold">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-black mb-2">
              🏗️ BUILT TO ORDER - 1-2 DAYS PROCESSING TIME
            </h2>
            <p className="text-black">
              Each RDSSEIKO watch is meticulously assembled when you order for guaranteed quality
            </p>
          </div>
        </div>
      </section>

      {/* Shipping Methods */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-serif font-bold text-white mb-6">
              Royal Mail Shipping Options
            </h2>
            <p className="text-xl text-gray-300">
              Choose the delivery method that suits your needs
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {shippingMethods.map((method, index) => (
              <motion.div
                key={index}
                className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-8 hover:border-gold/30 transition-colors duration-300"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -5 }}
              >
                <div className="flex items-center space-x-4 mb-6">
                  <div className="p-3 bg-gold/10 rounded-lg">
                    <method.icon className="w-8 h-8 text-gold" />
                  </div>
                  <div>
                    <h3 className="text-xl font-serif font-bold text-white">
                      {method.name}
                    </h3>
                    <p className="text-gray-400">{method.description}</p>
                  </div>
                </div>
                
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    <Clock className="w-5 h-5 text-gold" />
                    <span className="text-white font-semibold">{method.time}</span>
                  </div>
                </div>

                <div className="space-y-2 text-sm text-gray-300">
                  <div className="flex items-center space-x-2">
                    <Package className="w-4 h-4 text-blue-400" />
                    <span>Secure packaging included</span>
                  </div>
                  {method.name.includes('Tracked') || method.name.includes('Special') ? (
                    <div className="flex items-center space-x-2">
                      <MapPin className="w-4 h-4 text-purple-400" />
                      <span>Real-time tracking provided</span>
                    </div>
                  ) : null}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Processing Steps */}
      <section className="py-16 bg-gradient-to-b from-black to-navy">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-serif font-bold text-white mb-6">
              Order Processing Timeline
            </h2>
            <p className="text-xl text-gray-300">
              From order to your door - here's what happens
            </p>
          </motion.div>

          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-gold via-gold to-transparent hidden lg:block" />

            <div className="space-y-12">
              {processingSteps.map((step, index) => (
                <motion.div
                  key={index}
                  className={`flex items-center ${
                    index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'
                  } flex-col lg:space-x-8`}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className={`w-full lg:w-1/2 ${index % 2 === 0 ? 'lg:pr-8 lg:text-right' : 'lg:pl-8'}`}>
                    <div className="bg-black/50 backdrop-blur-sm rounded-xl p-6 border border-gray-800">
                      <div className="flex items-center space-x-3 mb-3">
                        <div className="w-8 h-8 bg-gold text-black rounded-full flex items-center justify-center font-bold">
                          {step.step}
                        </div>
                        <h3 className="text-xl font-serif font-bold text-white">
                          {step.title}
                        </h3>
                      </div>
                      <p className="text-gray-300 mb-2">{step.description}</p>
                      <div className="text-gold font-semibold text-sm">
                        ⏱️ {step.time}
                      </div>
                    </div>
                  </div>

                  {/* Timeline Dot */}
                  <div className="relative z-10 hidden lg:block">
                    <div className="w-4 h-4 bg-gold rounded-full border-4 border-navy" />
                  </div>

                  <div className="w-full lg:w-1/2" />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* International Shipping */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-8"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="text-center mb-8">
              <MapPin className="w-12 h-12 text-gold mx-auto mb-4" />
              <h2 className="text-2xl font-serif font-bold text-white mb-4">
                International Shipping
              </h2>
              <p className="text-gray-300">
                We ship worldwide via Royal Mail International services
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <h3 className="text-lg font-semibold text-gold mb-3">Europe</h3>
                <p className="text-gray-300 text-sm mb-2">3-5 business days</p>
              </div>
              <div className="text-center">
                <h3 className="text-lg font-semibold text-gold mb-3">North America</h3>
                <p className="text-gray-300 text-sm mb-2">5-7 business days</p>
              </div>
              <div className="text-center">
                <h3 className="text-lg font-semibold text-gold mb-3">Rest of World</h3>
                <p className="text-gray-300 text-sm mb-2">7-14 business days</p>
              </div>
            </div>

            <div className="mt-8 p-4 bg-yellow-900/20 border border-yellow-700 rounded-lg">
              <p className="text-yellow-300 text-sm">
                <strong>Important:</strong> International customers may be subject to customs duties and taxes. 
                These charges are the responsibility of the recipient and are not included in our shipping costs.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-gradient-to-r from-navy via-black to-navy">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-serif font-bold text-white mb-6">
              Questions About Shipping?
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Our customer service team is here to help with any shipping inquiries
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.a
                href="https://wa.me/07361837234"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-gold text-black px-8 py-4 rounded-lg font-semibold hover:bg-yellow-400 transition-colors duration-200 flex items-center justify-center space-x-2"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Phone className="w-5 h-5" />
                <span>WhatsApp: 07361837234</span>
              </motion.a>
              
              <motion.a
                href="mailto:info@rdsseiko.com"
                className="border border-gray-600 text-white px-8 py-4 rounded-lg font-semibold hover:border-gold hover:text-gold transition-colors duration-200 flex items-center justify-center space-x-2"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Mail className="w-5 h-5" />
                <span>info@rdsseiko.com</span>
              </motion.a>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Shipping;