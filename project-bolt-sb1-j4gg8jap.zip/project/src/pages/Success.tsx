import React, { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, Package, ArrowRight, Crown } from 'lucide-react';
import { getProductByPriceId } from '../stripe-config';

const Success = () => {
  const [searchParams] = useSearchParams();
  const sessionId = searchParams.get('session_id');
  const [orderDetails, setOrderDetails] = useState<any>(null);

  useEffect(() => {
    // In a real app, you might fetch order details from your backend
    // For now, we'll simulate order details
    if (sessionId) {
      setOrderDetails({
        id: sessionId,
        date: new Date().toLocaleDateString(),
        total: '£120.00',
        product: getProductByPriceId('price_1RxzPxKCH4uiw91JqcYbhJga')
      });
    }
  }, [sessionId]);

  return (
    <div className="min-h-screen bg-navy pt-28">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <motion.div
          className="text-center"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
        >
          {/* Success Icon */}
          <motion.div
            className="w-24 h-24 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-8"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <CheckCircle className="w-12 h-12 text-white" />
          </motion.div>

          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <h1 className="text-4xl lg:text-5xl font-serif font-bold text-white mb-4">
              Payment Successful!
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Thank you for your purchase. Your order has been confirmed.
            </p>
          </motion.div>

          {/* Order Details */}
          {orderDetails && (
            <motion.div
              className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-8 mb-8 max-w-2xl mx-auto"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
            >
              <div className="flex items-center justify-center space-x-3 mb-6">
                <Package className="w-6 h-6 text-gold" />
                <h2 className="text-2xl font-serif font-bold text-white">Order Summary</h2>
              </div>

              <div className="space-y-4 text-left">
                <div className="flex justify-between items-center py-3 border-b border-gray-700">
                  <span className="text-gray-400">Order ID:</span>
                  <span className="text-white font-mono text-sm">{orderDetails.id}</span>
                </div>
                
                <div className="flex justify-between items-center py-3 border-b border-gray-700">
                  <span className="text-gray-400">Date:</span>
                  <span className="text-white">{orderDetails.date}</span>
                </div>

                {orderDetails.product && (
                  <div className="flex justify-between items-center py-3 border-b border-gray-700">
                    <span className="text-gray-400">Product:</span>
                    <span className="text-white">{orderDetails.product.name}</span>
                  </div>
                )}
                
                <div className="flex justify-between items-center py-3">
                  <span className="text-gray-400">Total:</span>
                  <span className="text-gold font-bold text-xl">{orderDetails.total}</span>
                </div>
              </div>
            </motion.div>
          )}

          {/* What's Next */}
          <motion.div
            className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-8 mb-8 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.8 }}
          >
            <h3 className="text-xl font-serif font-bold text-white mb-6">What happens next?</h3>
            
            <div className="space-y-4 text-left">
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-gold rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-black font-bold text-sm">1</span>
                </div>
                <div>
                  <h4 className="text-white font-semibold mb-1">Order Confirmation</h4>
                  <p className="text-gray-400 text-sm">You'll receive an email confirmation with your order details within the next few minutes.</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-gold rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-black font-bold text-sm">2</span>
                </div>
                <div>
                  <h4 className="text-white font-semibold mb-1">Processing</h4>
                  <p className="text-gray-400 text-sm">Your watch will be carefully prepared and quality checked before shipping (1-2 business days).</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-gold rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-black font-bold text-sm">3</span>
                </div>
                <div>
                  <h4 className="text-white font-semibold mb-1">Shipping</h4>
                  <p className="text-gray-400 text-sm">Your order will be shipped with tracking information provided via email.</p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Actions */}
          <motion.div
            className="flex flex-col sm:flex-row gap-4 justify-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 1 }}
          >
            <Link
              to="/catalog"
              className="bg-gold text-black px-8 py-4 rounded-lg font-semibold hover:bg-yellow-400 transition-colors duration-200 flex items-center justify-center space-x-2"
            >
              <span>Continue Shopping</span>
              <ArrowRight className="w-5 h-5" />
            </Link>
            
            <Link
              to="/"
              className="border border-gray-600 text-white px-8 py-4 rounded-lg font-semibold hover:border-gold hover:text-gold transition-colors duration-200 flex items-center justify-center space-x-2"
            >
              <Crown className="w-5 h-5" />
              <span>Back to Home</span>
            </Link>
          </motion.div>

          {/* Support */}
          <motion.div
            className="mt-12 text-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 1.2 }}
          >
            <p className="text-gray-400 mb-4">
              Need help with your order?
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="https://wa.me/07361837234"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gold hover:text-yellow-400 transition-colors"
              >
                WhatsApp: 07361837234
              </a>
              <span className="hidden sm:inline text-gray-600">•</span>
              <a
                href="mailto:info@rdsseiko.com"
                className="text-gold hover:text-yellow-400 transition-colors"
              >
                info@rdsseiko.com
              </a>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
};

export default Success;