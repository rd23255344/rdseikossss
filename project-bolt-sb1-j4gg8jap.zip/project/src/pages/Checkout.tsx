import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  CreditCard, 
  Lock, 
  Truck, 
  CheckCircle,
  AlertCircle,
  Package,
  Shield
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatPrice } from '../utils/currency';

const Checkout = () => {
  const { state, dispatch } = useApp();
  const navigate = useNavigate();
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderComplete, setOrderComplete] = useState(false);
  const [orderNumber, setOrderNumber] = useState('');

  const [formData, setFormData] = useState({
    // Billing Information
    firstName: state.user?.firstName || '',
    lastName: state.user?.lastName || '',
    email: state.user?.email || '',
    phone: '',
    
    // Shipping Address
    address: '',
    city: '',
    postalCode: '',
    country: 'United Kingdom',
    
    // Payment Information
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardName: '',
    
    // Options
    sameAsShipping: true,
    saveInfo: false
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const subtotal = state.cart.reduce((sum, item) => sum + (item.watch.price * item.quantity), 0);
  
  // Location-based shipping costs
  const getShippingCost = (country: string) => {
    // UK domestic
    if (country === 'United Kingdom') {
      return 2; // £2 for UK
    }
    
    // World Zone 2 (Australia, Singapore, etc.)
    const worldZone2Countries = [
      'Australia', 'New Zealand', 'Singapore', 'Hong Kong', 'Malaysia', 
      'Thailand', 'Philippines', 'Indonesia', 'Vietnam', 'South Korea',
      'Taiwan', 'India', 'China', 'Japan'
    ];
    
    // World Zone 3 (USA only)
    if (country === 'United States') {
      return 15.50; // International Tracked
    }
    
    // World Zone 2
    if (worldZone2Countries.includes(country)) {
      return 15.50; // International Tracked
    }
    
    // Europe and other countries
    const europeanCountries = [
      'Ireland', 'France', 'Germany', 'Netherlands', 'Belgium', 'Spain',
      'Italy', 'Portugal', 'Switzerland', 'Austria', 'Denmark', 'Sweden',
      'Norway', 'Finland', 'Poland', 'Czech Republic', 'Hungary', 'Greece',
      'Turkey', 'Romania', 'Bulgaria', 'Croatia', 'Serbia', 'Slovenia',
      'Slovakia', 'Estonia', 'Latvia', 'Lithuania'
    ];
    
    if (europeanCountries.includes(country)) {
      return 10.20; // International Tracked for Europe
    }
    
    // All other countries
    return 16.40; // International Standard
  };
  
  const shipping = getShippingCost(formData.country);
  const total = subtotal + shipping;

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    // Required fields
    if (!formData.firstName) newErrors.firstName = 'First name is required';
    if (!formData.lastName) newErrors.lastName = 'Last name is required';
    if (!formData.email) newErrors.email = 'Email is required';
    if (!formData.phone) newErrors.phone = 'Phone number is required';
    if (!formData.address) newErrors.address = 'Address is required';
    if (!formData.city) newErrors.city = 'City is required';
    if (!formData.postalCode) newErrors.postalCode = 'Postal code is required';
    if (!formData.cardNumber) newErrors.cardNumber = 'Card number is required';
    if (!formData.expiryDate) newErrors.expiryDate = 'Expiry date is required';
    if (!formData.cvv) newErrors.cvv = 'CVV is required';
    if (!formData.cardName) newErrors.cardName = 'Cardholder name is required';

    // Email validation
    if (formData.email && !/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    // Card number validation (basic)
    if (formData.cardNumber && formData.cardNumber.replace(/\s/g, '').length < 16) {
      newErrors.cardNumber = 'Please enter a valid card number';
    }

    // CVV validation
    if (formData.cvv && (formData.cvv.length < 3 || formData.cvv.length > 4)) {
      newErrors.cvv = 'Please enter a valid CVV';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsProcessing(true);

    // Simulate payment processing
    setTimeout(() => {
      const newOrderNumber = `RDS-${Date.now()}`;
      setOrderNumber(newOrderNumber);
      setOrderComplete(true);
      setIsProcessing(false);
      
      // Clear cart
      dispatch({ type: 'CLEAR_CART' });
      
      // Store order in user's order history (if logged in)
      if (state.user) {
        const order = {
          id: newOrderNumber,
          items: state.cart,
          total: total,
          status: 'processing' as const,
          date: new Date().toISOString(),
          trackingNumber: `TRK${Date.now()}`
        };
        
        // In a real app, this would be saved to the backend
        console.log('Order placed:', order);
      }
    }, 3000);
  };

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = matches && matches[0] || '';
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    if (parts.length) {
      return parts.join(' ');
    } else {
      return v;
    }
  };

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCardNumber(e.target.value);
    setFormData({ ...formData, cardNumber: formatted });
  };

  if (orderComplete) {
    return (
      <div className="min-h-screen bg-navy pt-28">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <motion.div
            className="text-center"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
          >
            <motion.div
              className="w-24 h-24 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-8"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <CheckCircle className="w-12 h-12 text-white" />
            </motion.div>

            <h1 className="text-4xl font-serif font-bold text-white mb-4">
              Order Confirmed!
            </h1>
            
            <p className="text-xl text-gray-300 mb-6">
              Thank you for your purchase. Your order has been received and is being processed.
            </p>

            <div className="bg-black/50 rounded-xl border border-gray-800 p-6 mb-8 max-w-md mx-auto">
              <h3 className="text-lg font-semibold text-gold mb-4">Order Details</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Order Number:</span>
                  <span className="text-white font-semibold">{orderNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Total:</span>
                  <span className="text-gold font-bold">{formatPrice(total, state.currency)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Status:</span>
                  <span className="text-green-400">Processing</span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <p className="text-gray-300">
                A confirmation email has been sent to <span className="text-gold">{formData.email}</span>
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link
                  to="/catalog"
                  className="bg-gold text-black px-8 py-3 rounded-lg font-semibold hover:bg-yellow-400 transition-colors"
                >
                  Continue Shopping
                </Link>
                <Link
                  to="/"
                  className="border border-gray-600 text-white px-8 py-3 rounded-lg font-semibold hover:border-gold hover:text-gold transition-colors"
                >
                  Back to Home
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  if (state.cart.length === 0) {
    navigate('/cart');
    return null;
  }

  return (
    <div className="min-h-screen bg-navy pt-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          className="mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Link
            to="/cart"
            className="flex items-center space-x-2 text-gray-400 hover:text-gold transition-colors mb-4"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Cart</span>
          </Link>
          
          <h1 className="text-3xl lg:text-4xl font-serif font-bold text-white mb-2">
            Secure Checkout
          </h1>
          <p className="text-gray-400">
            Complete your order securely
          </p>
        </motion.div>

        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Checkout Form */}
            <div className="lg:col-span-2 space-y-8">
              {/* Contact Information */}
              <motion.div
                className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <h2 className="text-xl font-serif font-bold text-white mb-6">
                  Contact Information
                </h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-white font-semibold mb-2">
                      First Name *
                    </label>
                    <input
                      type="text"
                      value={formData.firstName}
                      onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                      className={`w-full bg-gray-900 text-white rounded-lg px-4 py-3 border ${
                        errors.firstName ? 'border-red-500' : 'border-gray-700'
                      } focus:border-gold focus:outline-none`}
                      required
                    />
                    {errors.firstName && (
                      <p className="text-red-400 text-sm mt-1">{errors.firstName}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-white font-semibold mb-2">
                      Last Name *
                    </label>
                    <input
                      type="text"
                      value={formData.lastName}
                      onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                      className={`w-full bg-gray-900 text-white rounded-lg px-4 py-3 border ${
                        errors.lastName ? 'border-red-500' : 'border-gray-700'
                      } focus:border-gold focus:outline-none`}
                      required
                    />
                    {errors.lastName && (
                      <p className="text-red-400 text-sm mt-1">{errors.lastName}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-white font-semibold mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className={`w-full bg-gray-900 text-white rounded-lg px-4 py-3 border ${
                        errors.email ? 'border-red-500' : 'border-gray-700'
                      } focus:border-gold focus:outline-none`}
                      required
                    />
                    {errors.email && (
                      <p className="text-red-400 text-sm mt-1">{errors.email}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-white font-semibold mb-2">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className={`w-full bg-gray-900 text-white rounded-lg px-4 py-3 border ${
                        errors.phone ? 'border-red-500' : 'border-gray-700'
                      } focus:border-gold focus:outline-none`}
                      required
                    />
                    {errors.phone && (
                      <p className="text-red-400 text-sm mt-1">{errors.phone}</p>
                    )}
                  </div>
                </div>
              </motion.div>

              {/* Shipping Address */}
              <motion.div
                className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
              >
                <h2 className="text-xl font-serif font-bold text-white mb-6">
                  Shipping Address
                </h2>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-white font-semibold mb-2">
                      Street Address *
                    </label>
                    <input
                      type="text"
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      className={`w-full bg-gray-900 text-white rounded-lg px-4 py-3 border ${
                        errors.address ? 'border-red-500' : 'border-gray-700'
                      } focus:border-gold focus:outline-none`}
                      placeholder="123 Main Street"
                      required
                    />
                    {errors.address && (
                      <p className="text-red-400 text-sm mt-1">{errors.address}</p>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-white font-semibold mb-2">
                        City *
                      </label>
                      <input
                        type="text"
                        value={formData.city}
                        onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                        className={`w-full bg-gray-900 text-white rounded-lg px-4 py-3 border ${
                          errors.city ? 'border-red-500' : 'border-gray-700'
                        } focus:border-gold focus:outline-none`}
                        required
                      />
                      {errors.city && (
                        <p className="text-red-400 text-sm mt-1">{errors.city}</p>
                      )}
                    </div>

                    <div>
                      <label className="block text-white font-semibold mb-2">
                        Postal Code *
                      </label>
                      <input
                        type="text"
                        value={formData.postalCode}
                        onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
                        className={`w-full bg-gray-900 text-white rounded-lg px-4 py-3 border ${
                          errors.postalCode ? 'border-red-500' : 'border-gray-700'
                        } focus:border-gold focus:outline-none`}
                        required
                      />
                      {errors.postalCode && (
                        <p className="text-red-400 text-sm mt-1">{errors.postalCode}</p>
                      )}
                    </div>

                    <div>
                      <label className="block text-white font-semibold mb-2">
                        Country *
                      </label>
                      <select
                        value={formData.country}
                        onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                        className="w-full bg-gray-900 text-white rounded-lg px-4 py-3 border border-gray-700 focus:border-gold focus:outline-none"
                        required
                      >
                        <option value="United Kingdom">United Kingdom</option>
                        <option value="Ireland">Ireland</option>
                        <option value="France">France</option>
                        <option value="Germany">Germany</option>
                        <option value="Netherlands">Netherlands</option>
                        <option value="Belgium">Belgium</option>
                        <option value="Spain">Spain</option>
                        <option value="Italy">Italy</option>
                        <option value="Portugal">Portugal</option>
                        <option value="Switzerland">Switzerland</option>
                        <option value="Austria">Austria</option>
                        <option value="Denmark">Denmark</option>
                        <option value="Sweden">Sweden</option>
                        <option value="Norway">Norway</option>
                        <option value="Finland">Finland</option>
                        <option value="Poland">Poland</option>
                        <option value="Czech Republic">Czech Republic</option>
                        <option value="Hungary">Hungary</option>
                        <option value="Greece">Greece</option>
                        <option value="Turkey">Turkey</option>
                        <option value="United States">United States</option>
                        <option value="Canada">Canada</option>
                        <option value="Mexico">Mexico</option>
                        <option value="Australia">Australia</option>
                        <option value="New Zealand">New Zealand</option>
                        <option value="Singapore">Singapore</option>
                        <option value="Japan">Japan</option>
                        <option value="South Korea">South Korea</option>
                        <option value="Hong Kong">Hong Kong</option>
                        <option value="Taiwan">Taiwan</option>
                        <option value="Malaysia">Malaysia</option>
                        <option value="Thailand">Thailand</option>
                        <option value="Philippines">Philippines</option>
                        <option value="Indonesia">Indonesia</option>
                        <option value="Vietnam">Vietnam</option>
                        <option value="India">India</option>
                        <option value="China">China</option>
                        <option value="UAE">United Arab Emirates</option>
                        <option value="Saudi Arabia">Saudi Arabia</option>
                        <option value="Qatar">Qatar</option>
                        <option value="Kuwait">Kuwait</option>
                        <option value="Bahrain">Bahrain</option>
                        <option value="Oman">Oman</option>
                        <option value="Israel">Israel</option>
                        <option value="South Africa">South Africa</option>
                        <option value="Egypt">Egypt</option>
                        <option value="Morocco">Morocco</option>
                        <option value="Brazil">Brazil</option>
                        <option value="Argentina">Argentina</option>
                        <option value="Chile">Chile</option>
                        <option value="Colombia">Colombia</option>
                        <option value="Peru">Peru</option>
                        <option value="Russia">Russia</option>
                        <option value="Ukraine">Ukraine</option>
                        <option value="Romania">Romania</option>
                        <option value="Bulgaria">Bulgaria</option>
                        <option value="Croatia">Croatia</option>
                        <option value="Serbia">Serbia</option>
                        <option value="Slovenia">Slovenia</option>
                        <option value="Slovakia">Slovakia</option>
                        <option value="Estonia">Estonia</option>
                        <option value="Latvia">Latvia</option>
                        <option value="Lithuania">Lithuania</option>
                      </select>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Payment Information */}
              <motion.div
                className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
              >
                <div className="flex items-center space-x-3 mb-6">
                  <Lock className="w-6 h-6 text-green-400" />
                  <h2 className="text-xl font-serif font-bold text-white">
                    Payment Information
                  </h2>
                  <span className="text-xs text-green-400 bg-green-400/10 px-2 py-1 rounded">
                    SECURE
                  </span>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-white font-semibold mb-2">
                      Cardholder Name *
                    </label>
                    <input
                      type="text"
                      value={formData.cardName}
                      onChange={(e) => setFormData({ ...formData, cardName: e.target.value })}
                      className={`w-full bg-gray-900 text-white rounded-lg px-4 py-3 border ${
                        errors.cardName ? 'border-red-500' : 'border-gray-700'
                      } focus:border-gold focus:outline-none`}
                      placeholder="John Doe"
                      required
                    />
                    {errors.cardName && (
                      <p className="text-red-400 text-sm mt-1">{errors.cardName}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-white font-semibold mb-2">
                      Card Number *
                    </label>
                    <input
                      type="text"
                      value={formData.cardNumber}
                      onChange={handleCardNumberChange}
                      className={`w-full bg-gray-900 text-white rounded-lg px-4 py-3 border ${
                        errors.cardNumber ? 'border-red-500' : 'border-gray-700'
                      } focus:border-gold focus:outline-none`}
                      placeholder="1234 5678 9012 3456"
                      maxLength={19}
                      required
                    />
                    {errors.cardNumber && (
                      <p className="text-red-400 text-sm mt-1">{errors.cardNumber}</p>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-white font-semibold mb-2">
                        Expiry Date *
                      </label>
                      <input
                        type="text"
                        value={formData.expiryDate}
                        onChange={(e) => {
                          let value = e.target.value.replace(/\D/g, '');
                          if (value.length >= 2) {
                            value = value.substring(0, 2) + '/' + value.substring(2, 4);
                          }
                          setFormData({ ...formData, expiryDate: value });
                        }}
                        className={`w-full bg-gray-900 text-white rounded-lg px-4 py-3 border ${
                          errors.expiryDate ? 'border-red-500' : 'border-gray-700'
                        } focus:border-gold focus:outline-none`}
                        placeholder="MM/YY"
                        maxLength={5}
                        required
                      />
                      {errors.expiryDate && (
                        <p className="text-red-400 text-sm mt-1">{errors.expiryDate}</p>
                      )}
                    </div>

                    <div>
                      <label className="block text-white font-semibold mb-2">
                        CVV *
                      </label>
                      <input
                        type="text"
                        value={formData.cvv}
                        onChange={(e) => {
                          const value = e.target.value.replace(/\D/g, '');
                          setFormData({ ...formData, cvv: value });
                        }}
                        className={`w-full bg-gray-900 text-white rounded-lg px-4 py-3 border ${
                          errors.cvv ? 'border-red-500' : 'border-gray-700'
                        } focus:border-gold focus:outline-none`}
                        placeholder="123"
                        maxLength={4}
                        required
                      />
                      {errors.cvv && (
                        <p className="text-red-400 text-sm mt-1">{errors.cvv}</p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Security Notice */}
                <div className="mt-6 p-4 bg-green-900/20 border border-green-700 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <Shield className="w-5 h-5 text-green-400" />
                    <span className="text-green-300 text-sm">
                      Your payment information is encrypted and secure
                    </span>
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <motion.div
                className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6 sticky top-32"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.5 }}
              >
                <h2 className="text-xl font-serif font-bold text-white mb-6">
                  Order Summary
                </h2>

                {/* Cart Items */}
                <div className="space-y-4 mb-6">
                  {state.cart.map((item) => (
                    <div key={item.watch.id} className="flex items-center space-x-3">
                      <img
                        src={item.watch.image}
                        alt={item.watch.name}
                        className="w-12 h-12 object-cover rounded-lg"
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="text-white font-semibold text-sm truncate">
                          {item.watch.name}
                        </h4>
                        <p className="text-gray-400 text-xs">Qty: {item.quantity}</p>
                      </div>
                      <div className="text-gold font-semibold text-sm">
                        {formatPrice(item.watch.price * item.quantity, state.currency)}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Pricing Breakdown */}
                <div className="space-y-3 mb-6 pt-6 border-t border-gray-700">
                  <div className="flex justify-between text-gray-300">
                    <span>Subtotal</span>
                    <span>{formatPrice(subtotal, state.currency)}</span>
                  </div>
                  
                  <div className="flex justify-between text-gray-300">
                    <span>Shipping</span>
                    <span>{formatPrice(shipping, state.currency)}</span>
                  </div>
                  
                  <div className="border-t border-gray-700 pt-3">
                    <div className="flex justify-between text-xl font-bold">
                      <span className="text-white">Total</span>
                      <span className="text-gold">{formatPrice(total, state.currency)}</span>
                    </div>
                  </div>
                </div>

                {/* Place Order Button */}
                <motion.button
                  type="submit"
                  className="w-full bg-gold text-black py-4 rounded-lg font-semibold hover:bg-yellow-400 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                  whileHover={{ scale: isProcessing ? 1 : 1.02 }}
                  whileTap={{ scale: isProcessing ? 1 : 0.98 }}
                  disabled={isProcessing}
                >
                  {isProcessing ? (
                    <>
                      <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                      <span>Processing Order...</span>
                    </>
                  ) : (
                    <>
                      <CreditCard className="w-5 h-5" />
                      <span>Place Order</span>
                    </>
                  )}
                </motion.button>

                {/* Security Features */}
                <div className="mt-6 pt-6 border-t border-gray-700">
                  <div className="text-center text-xs text-gray-400 space-y-2">
                    <div className="flex items-center justify-center space-x-2">
                      <Lock className="w-4 h-4" />
                      <span>256-bit SSL Encryption</span>
                    </div>
                    <div className="flex items-center justify-center space-x-2">
                      <Truck className="w-4 h-4" />
                      <span>Royal Mail Tracked Delivery</span>
                    </div>
                    <div className="flex items-center justify-center space-x-2">
                      <Shield className="w-4 h-4" />
                      <span>6 Month Workmanship Warranty</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Checkout;