import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { X, Star } from 'lucide-react';
import ProductCard from '../components/Product/ProductCard';
import { watches } from '../data/watches';

const Catalog = () => {
  const [selectedWatch, setSelectedWatch] = useState<any>(null);
  const [isSpecsModalOpen, setIsSpecsModalOpen] = useState(false);

  const handleSpecsClick = (watch: any) => {
    setSelectedWatch(watch);
    setIsSpecsModalOpen(true);
  };

  return (
    <>
      <div className="min-h-screen bg-navy pt-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1 className="text-4xl lg:text-5xl font-serif font-bold text-white mb-6">
            OUR WATCHES
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Discover our collection of meticulously crafted luxury timepieces
          </p>
        </motion.div>

        {/* Products Grid */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          {watches.map((watch, index) => (
            <motion.div
              key={watch.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <ProductCard watch={watch} onSpecsClick={handleSpecsClick} />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>

      {/* Specifications Modal */}
      {isSpecsModalOpen && selectedWatch && (
        <motion.div
          className="fixed inset-0 bg-navy z-50 overflow-y-auto"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <div className="min-h-screen">
            {/* Header */}
            <div className="sticky top-0 bg-navy/95 backdrop-blur-md border-b border-gray-800 z-10">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
                <div className="flex items-center justify-between">
                  <motion.button
                    onClick={() => setIsSpecsModalOpen(false)}
                    className="flex items-center space-x-2 text-gray-400 hover:text-gold transition-colors"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.6 }}
                  >
                    <X className="w-5 h-5" />
                    <span>Back to Catalog</span>
                  </motion.button>
                  
                  <h1 className="text-2xl font-serif font-bold text-white">
                    Watch Specifications
                  </h1>
                  
                  <div className="w-24" /> {/* Spacer for centering */}
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
                {/* Images Section */}
                <motion.div
                  className="space-y-6"
                  initial={{ opacity: 0, x: -50 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8 }}
                >
                  {/* Main Image */}
                  <div className="aspect-square bg-black/50 rounded-2xl overflow-hidden border border-gray-800">
                    <img
                      src={selectedWatch.images[0]}
                      alt={selectedWatch.name}
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    />
                  </div>
                  
                  {/* Thumbnail Images */}
                  {selectedWatch.images.length > 1 && (
                    <div className="flex space-x-4">
                      {selectedWatch.images.map((image: string, index: number) => (
                        <div key={index} className="w-20 h-20 rounded-lg overflow-hidden border border-gray-700">
                          <img
                            src={image}
                            alt={`${selectedWatch.name} ${index + 1}`}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      ))}
                    </div>
                  )}
                </motion.div>

                {/* Details Section */}
                <motion.div
                  className="space-y-8"
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8, delay: 0.2 }}
                >
                  {/* Product Info */}
                  <div>
                    <div className="flex items-center space-x-3 mb-4">
                      <span className="bg-gold/10 border border-gold/20 rounded-full px-4 py-1 text-gold text-sm font-semibold">
                        {selectedWatch.collection}
                      </span>
                      {selectedWatch.isNew && (
                        <span className="bg-gold text-black px-3 py-1 rounded-full text-xs font-bold">
                          NEW
                        </span>
                      )}
                      {selectedWatch.isBestseller && (
                        <span className="bg-silver text-black px-3 py-1 rounded-full text-xs font-bold">
                          BESTSELLER
                        </span>
                      )}
                    </div>
                    
                    <h2 className="text-4xl font-serif font-bold text-white mb-6">
                      {selectedWatch.name}
                    </h2>
                    
                    {/* Rating */}
                    <div className="flex items-center gap-4 mb-6">
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-5 h-5 ${
                              i < Math.floor(selectedWatch.rating) 
                                ? 'text-gold fill-gold' 
                                : 'text-gray-600'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-gray-400">
                        {selectedWatch.rating} ({selectedWatch.reviewCount} reviews)
                      </span>
                    </div>

                    {/* Price */}
                    <div className="text-4xl font-bold text-gold mb-8">
                      ${selectedWatch.price.toLocaleString()}
                    </div>
                  </div>

                  {/* Description */}
                  <div className="bg-black/50 rounded-xl p-6 border border-gray-800">
                    <h3 className="text-xl font-serif font-bold text-white mb-4">Description</h3>
                    <p className="text-gray-300 leading-relaxed">
                      {selectedWatch.description}
                    </p>
                  </div>

                  {/* Specifications */}
                  <div className="bg-black/50 rounded-xl p-6 border border-gray-800">
                    <h3 className="text-xl font-serif font-bold text-white mb-6">Technical Specifications</h3>
                    <div className="grid grid-cols-1 gap-4">
                      {Object.entries(selectedWatch.specifications).map(([key, value]) => (
                        <div key={key} className="flex flex-col sm:flex-row sm:justify-between py-3 border-b border-gray-800 last:border-b-0">
                          <span className="text-gray-400 font-medium capitalize mb-1 sm:mb-0">
                            {key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}:
                          </span>
                          <span className="text-white font-semibold sm:text-right sm:max-w-xs">
                            {value}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-col sm:flex-row gap-4">
                    <motion.button
                      onClick={() => {
                        // Add to cart logic would go here
                        setIsSpecsModalOpen(false);
                      }}
                      className="flex-1 bg-gold text-black py-4 rounded-lg font-semibold hover:bg-yellow-400 transition-colors duration-200 flex items-center justify-center space-x-2"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <span>Add to Cart</span>
                    </motion.button>
                    <Link
                      to={`/product/${selectedWatch.id}`}
                      className="flex-1 border border-gray-600 text-white py-4 rounded-lg font-semibold hover:border-gold hover:text-gold transition-colors text-center flex items-center justify-center space-x-2"
                      onClick={() => setIsSpecsModalOpen(false)}
                    >
                      <span>View Full Details</span>
                    </Link>
                  </div>

                  {/* Features */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-6 border-t border-gray-800">
                    <div className="flex items-center space-x-3 text-gray-300">
                      <div className="w-8 h-8 bg-gold/10 rounded-full flex items-center justify-center">
                        <span className="text-gold text-xs">🛡️</span>
                      </div>
                      <span className="text-sm">6 Month Warranty</span>
                    </div>
                    <div className="flex items-center space-x-3 text-gray-300">
                      <div className="w-8 h-8 bg-gold/10 rounded-full flex items-center justify-center">
                        <span className="text-gold text-xs">🚚</span>
                      </div>
                      <span className="text-sm">Free Shipping</span>
                    </div>
                    <div className="flex items-center space-x-3 text-gray-300">
                      <div className="w-8 h-8 bg-gold/10 rounded-full flex items-center justify-center">
                        <span className="text-gold text-xs">↩️</span>
                      </div>
                      <span className="text-sm">4-Day Returns</span>
                    </div>
                  </div>
                </motion.div>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </>
  );
};

export default Catalog;