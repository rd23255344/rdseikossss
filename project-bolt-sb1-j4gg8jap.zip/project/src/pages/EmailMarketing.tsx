import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Mail, 
  Send, 
  Users, 
  Eye, 
  MousePointer,
  Calendar,
  CheckCircle,
  AlertCircle,
  Plus,
  Edit,
  Trash2
} from 'lucide-react';

interface Campaign {
  id: string;
  name: string;
  subject: string;
  recipients: number;
  status: 'draft' | 'sent' | 'scheduled';
  openRate: number;
  clickRate: number;
  sentDate?: string;
  scheduledDate?: string;
}

const EmailMarketing = () => {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);

  const [isCreating, setIsCreating] = useState(false);
  const [newCampaign, setNewCampaign] = useState({
    name: '',
    subject: '',
    content: '',
    recipients: 'all'
  });
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleCreateCampaign = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newCampaign.name || !newCampaign.subject || !newCampaign.content) {
      setMessage({ type: 'error', text: 'Please fill in all required fields' });
      return;
    }

    const campaign: Campaign = {
      id: Date.now().toString(),
      name: newCampaign.name,
      subject: newCampaign.subject,
      recipients: newCampaign.recipients === 'all' ? 1500 : 750,
      status: 'draft',
      openRate: 0,
      clickRate: 0
    };

    setCampaigns([campaign, ...campaigns]);
    setNewCampaign({ name: '', subject: '', content: '', recipients: 'all' });
    setIsCreating(false);
    setMessage({ type: 'success', text: 'Campaign created successfully!' });
    
    setTimeout(() => setMessage(null), 3000);
  };

  const handleSendCampaign = (id: string) => {
    setCampaigns(campaigns.map(campaign => 
      campaign.id === id 
        ? { 
            ...campaign, 
            status: 'sent' as const, 
            sentDate: new Date().toISOString().split('T')[0],
            openRate: Math.random() * 30 + 15,
            clickRate: Math.random() * 8 + 2
          }
        : campaign
    ));
    setMessage({ type: 'success', text: 'Campaign sent successfully!' });
    setTimeout(() => setMessage(null), 3000);
  };

  const handleDeleteCampaign = (id: string) => {
    if (confirm('Are you sure you want to delete this campaign?')) {
      setCampaigns(campaigns.filter(campaign => campaign.id !== id));
      setMessage({ type: 'success', text: 'Campaign deleted successfully!' });
      setTimeout(() => setMessage(null), 3000);
    }
  };

  const totalSent = campaigns.filter(c => c.status === 'sent').reduce((sum, c) => sum + c.recipients, 0);
  const sentCampaigns = campaigns.filter(c => c.status === 'sent');
  const avgOpenRate = sentCampaigns.length > 0 ? sentCampaigns.reduce((sum, c) => sum + c.openRate, 0) / sentCampaigns.length : 0;
  const avgClickRate = sentCampaigns.length > 0 ? sentCampaigns.reduce((sum, c) => sum + c.clickRate, 0) / sentCampaigns.length : 0;

  return (
    <div className="min-h-screen bg-navy pt-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          className="mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Link
            to="/admin"
            className="flex items-center space-x-2 text-gray-400 hover:text-gold transition-colors mb-4"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Admin Dashboard</span>
          </Link>
          
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <Mail className="w-8 h-8 text-green-400" />
                <h1 className="text-3xl lg:text-4xl font-serif font-bold text-white">
                  Email Marketing
                </h1>
              </div>
              <p className="text-gray-400">
                Send newsletters and promotional emails to your customers
              </p>
            </div>
            
            <motion.button
              onClick={() => setIsCreating(true)}
              className="bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors flex items-center space-x-2"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Plus className="w-5 h-5" />
              <span>New Campaign</span>
            </motion.button>
          </div>
        </motion.div>

        {/* Message */}
        {message && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex items-center space-x-2 p-4 rounded-lg mb-6 ${
              message.type === 'success' 
                ? 'bg-green-900/50 border border-green-700 text-green-300' 
                : 'bg-red-900/50 border border-red-700 text-red-300'
            }`}
          >
            {message.type === 'success' ? (
              <CheckCircle className="w-5 h-5" />
            ) : (
              <AlertCircle className="w-5 h-5" />
            )}
            <span>{message.text}</span>
          </motion.div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {[
            {
              title: 'Total Campaigns',
              value: campaigns.length,
              icon: Mail,
              color: 'text-blue-400',
              bgColor: 'bg-blue-400/10'
            },
            {
              title: 'Emails Sent',
              value: totalSent.toLocaleString(),
              icon: Send,
              color: 'text-green-400',
              bgColor: 'bg-green-400/10'
            },
            {
              title: 'Avg. Open Rate',
              value: `${avgOpenRate.toFixed(1)}%`,
              icon: Eye,
              color: 'text-orange-400',
              bgColor: 'bg-orange-400/10'
            },
            {
              title: 'Avg. Click Rate',
              value: `${avgClickRate.toFixed(1)}%`,
              icon: MousePointer,
              color: 'text-purple-400',
              bgColor: 'bg-purple-400/10'
            }
          ].map((stat, index) => (
            <motion.div
              key={index}
              className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
            >
              <div className={`p-3 rounded-lg ${stat.bgColor} mb-4 w-fit`}>
                <stat.icon className={`w-6 h-6 ${stat.color}`} />
              </div>
              <h3 className="text-2xl font-bold text-white mb-1">{stat.value}</h3>
              <p className="text-gray-400 text-sm">{stat.title}</p>
            </motion.div>
          ))}
        </div>

        {/* Create Campaign Modal */}
        {isCreating && (
          <motion.div
            className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <motion.div
              className="bg-navy border border-gray-800 rounded-xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-serif font-bold text-white">Create New Campaign</h2>
                <button
                  onClick={() => setIsCreating(false)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  ×
                </button>
              </div>

              <form onSubmit={handleCreateCampaign} className="space-y-6">
                <div>
                  <label className="block text-white font-semibold mb-2">Campaign Name</label>
                  <input
                    type="text"
                    value={newCampaign.name}
                    onChange={(e) => setNewCampaign({ ...newCampaign, name: e.target.value })}
                    className="w-full bg-gray-900 text-white rounded-lg px-4 py-3 border border-gray-700 focus:border-gold focus:outline-none"
                    placeholder="e.g., Spring Collection Launch"
                    required
                  />
                </div>

                <div>
                  <label className="block text-white font-semibold mb-2">Email Subject</label>
                  <input
                    type="text"
                    value={newCampaign.subject}
                    onChange={(e) => setNewCampaign({ ...newCampaign, subject: e.target.value })}
                    className="w-full bg-gray-900 text-white rounded-lg px-4 py-3 border border-gray-700 focus:border-gold focus:outline-none"
                    placeholder="e.g., Discover Our Latest Luxury Timepieces"
                    required
                  />
                </div>

                <div>
                  <label className="block text-white font-semibold mb-2">Recipients</label>
                  <select
                    value={newCampaign.recipients}
                    onChange={(e) => setNewCampaign({ ...newCampaign, recipients: e.target.value })}
                    className="w-full bg-gray-900 text-white rounded-lg px-4 py-3 border border-gray-700 focus:border-gold focus:outline-none"
                  >
                    <option value="all">All Subscribers (1,500)</option>
                    <option value="customers">Customers Only (750)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-white font-semibold mb-2">Email Content</label>
                  <textarea
                    value={newCampaign.content}
                    onChange={(e) => setNewCampaign({ ...newCampaign, content: e.target.value })}
                    className="w-full bg-gray-900 text-white rounded-lg px-4 py-3 border border-gray-700 focus:border-gold focus:outline-none h-32"
                    placeholder="Write your email content here..."
                    required
                  />
                </div>

                <div className="flex space-x-4">
                  <button
                    type="submit"
                    className="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors"
                  >
                    Create Campaign
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsCreating(false)}
                    className="flex-1 border border-gray-600 text-white py-3 rounded-lg font-semibold hover:border-gold hover:text-gold transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}

        {/* Campaigns List */}
        <motion.div
          className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <h2 className="text-xl font-serif font-bold text-white mb-6">Email Campaigns</h2>
          
          <div className="overflow-x-auto">
            {campaigns.length === 0 ? (
              <div className="text-center py-12">
                <Mail className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">
                  No campaigns yet
                </h3>
                <p className="text-gray-400 mb-6">
                  Create your first email campaign to start reaching your customers
                </p>
                <button
                  onClick={() => setIsCreating(true)}
                  className="bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors"
                >
                  Create First Campaign
                </button>
              </div>
            ) : (
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-800">
                    <th className="text-left text-gray-400 font-semibold py-3">Campaign</th>
                    <th className="text-left text-gray-400 font-semibold py-3">Recipients</th>
                    <th className="text-left text-gray-400 font-semibold py-3">Status</th>
                    <th className="text-left text-gray-400 font-semibold py-3">Open Rate</th>
                    <th className="text-left text-gray-400 font-semibold py-3">Click Rate</th>
                    <th className="text-left text-gray-400 font-semibold py-3">Date</th>
                    <th className="text-left text-gray-400 font-semibold py-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {campaigns.map((campaign) => (
                    <tr key={campaign.id} className="border-b border-gray-800/50">
                      <td className="py-4">
                        <div>
                          <div className="text-white font-semibold">{campaign.name}</div>
                          <div className="text-gray-400 text-sm">{campaign.subject}</div>
                        </div>
                      </td>
                      <td className="py-4 text-gray-300">{campaign.recipients.toLocaleString()}</td>
                      <td className="py-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          campaign.status === 'sent' 
                            ? 'bg-green-900/50 text-green-300' 
                            : campaign.status === 'scheduled'
                            ? 'bg-blue-900/50 text-blue-300'
                            : 'bg-gray-700 text-gray-300'
                        }`}>
                          {campaign.status.charAt(0).toUpperCase() + campaign.status.slice(1)}
                        </span>
                      </td>
                      <td className="py-4 text-gray-300">
                        {campaign.status === 'sent' ? `${campaign.openRate.toFixed(1)}%` : '-'}
                      </td>
                      <td className="py-4 text-gray-300">
                        {campaign.status === 'sent' ? `${campaign.clickRate.toFixed(1)}%` : '-'}
                      </td>
                      <td className="py-4 text-gray-300">
                        {campaign.sentDate || campaign.scheduledDate || '-'}
                      </td>
                      <td className="py-4">
                        <div className="flex items-center space-x-2">
                          {campaign.status === 'draft' && (
                            <button
                              onClick={() => handleSendCampaign(campaign.id)}
                              className="bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700 transition-colors"
                            >
                              Send
                            </button>
                          )}
                          <button
                            onClick={() => handleDeleteCampaign(campaign.id)}
                            className="text-red-400 hover:text-red-300 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default EmailMarketing;