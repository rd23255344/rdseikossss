import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Crown, 
  Users, 
  ShoppingBag, 
  TrendingUp, 
  Eye, 
  Mail,
  Calendar,
  Star,
  Package,
  DollarSign
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { watches } from '../data/watches';

const AdminDashboard = () => {
  const { state } = useApp();
  const [users, setUsers] = useState<any[]>([]);
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalOrders: 0,
    totalRevenue: 0,
    totalProducts: 0
  });

  useEffect(() => {
    // Load users from localStorage
    const storedUsers = localStorage.getItem('rdsseiko_users');
    if (storedUsers) {
      const parsedUsers = JSON.parse(storedUsers);
      setUsers(parsedUsers);
      setStats(prev => ({
        totalProducts: watches.length,
        totalUsers: parsedUsers.length,
        totalOrders: parsedUsers.reduce((sum: number, user: any) => sum + (user.orders?.length || 0), 0),
        totalRevenue: parsedUsers.reduce((sum: number, user: any) => 
          sum + (user.orders?.reduce((orderSum: number, order: any) => orderSum + order.total, 0) || 0), 0
        )
      }));
    } else {
      // No users yet, set real stats
      setStats({
        totalUsers: 0,
        totalOrders: 0,
        totalRevenue: 0,
        totalProducts: watches.length
      });
    }
  }, []);

  const statCards = [
    {
      title: 'Total Users',
      value: stats.totalUsers,
      icon: Users,
      color: 'text-blue-400',
      bgColor: 'bg-blue-400/10'
    },
    {
      title: 'Total Orders',
      value: stats.totalOrders,
      icon: ShoppingBag,
      color: 'text-green-400',
      bgColor: 'bg-green-400/10'
    },
    {
      title: 'Total Revenue',
      value: `$${stats.totalRevenue.toLocaleString()}`,
      icon: DollarSign,
      color: 'text-gold',
      bgColor: 'bg-gold/10'
    },
    {
      title: 'Products',
      value: stats.totalProducts,
      icon: Package,
      color: 'text-purple-400',
      bgColor: 'bg-purple-400/10'
    }
  ];

  return (
    <div className="min-h-screen bg-navy pt-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          className="mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex items-center space-x-3 mb-4">
            <Crown className="w-8 h-8 text-gold" />
            <h1 className="text-3xl lg:text-4xl font-serif font-bold text-white">
              Admin Dashboard
            </h1>
          </div>
          <p className="text-gray-400">
            Welcome back, Boss! Here's your business overview.
          </p>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {statCards.map((stat, index) => (
            <motion.div
              key={index}
              className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg ${stat.bgColor}`}>
                  <stat.icon className={`w-6 h-6 ${stat.color}`} />
                </div>
                <TrendingUp className="w-5 h-5 text-green-400" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-1">{stat.value}</h3>
              <p className="text-gray-400 text-sm">{stat.title}</p>
            </motion.div>
          ))}
        </div>

        {/* Recent Users */}
        <motion.div
          className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-serif font-bold text-white">Recent Users</h2>
            <Users className="w-6 h-6 text-gold" />
          </div>
          
          {users.length === 0 ? (
            <p className="text-gray-400 text-center py-8">No users registered yet</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-800">
                    <th className="text-left text-gray-400 font-semibold py-3">Name</th>
                    <th className="text-left text-gray-400 font-semibold py-3">Email</th>
                    <th className="text-left text-gray-400 font-semibold py-3">Role</th>
                    <th className="text-left text-gray-400 font-semibold py-3">Wishlist</th>
                    <th className="text-left text-gray-400 font-semibold py-3">Orders</th>
                  </tr>
                </thead>
                <tbody>
                  {users.slice(0, 10).map((user, index) => (
                    <tr key={user.id} className="border-b border-gray-800/50">
                      <td className="py-3 text-white">
                        {user.firstName} {user.lastName}
                        {user.role === 'admin' && (
                          <Crown className="w-4 h-4 text-gold inline ml-2" />
                        )}
                      </td>
                      <td className="py-3 text-gray-300">{user.email}</td>
                      <td className="py-3">
                        <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                          user.role === 'admin' 
                            ? 'bg-gold/20 text-gold' 
                            : 'bg-gray-700 text-gray-300'
                        }`}>
                          {user.role || 'customer'}
                        </span>
                      </td>
                      <td className="py-3 text-gray-300">{user.wishlist?.length || 0}</td>
                      <td className="py-3 text-gray-300">{user.orders?.length || 0}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <div className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6">
            <div className="flex items-center space-x-3 mb-4">
              <Eye className="w-6 h-6 text-blue-400" />
              <h3 className="text-lg font-semibold text-white">Site Analytics</h3>
            </div>
            <p className="text-gray-400 text-sm mb-4">
              Monitor user behavior and site performance
            </p>
            <Link
              to="/admin/analytics"
              className="inline-block bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              View Analytics
            </Link>
          </div>

          <div className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6">
            <div className="flex items-center space-x-3 mb-4">
              <Mail className="w-6 h-6 text-green-400" />
              <h3 className="text-lg font-semibold text-white">Email Marketing</h3>
            </div>
            <p className="text-gray-400 text-sm mb-4">
              Send newsletters and promotional emails
            </p>
            <Link
              to="/admin/email"
              className="inline-block bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
            >
              Send Campaign
            </Link>
          </div>

          <div className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6">
            <div className="flex items-center space-x-3 mb-4">
              <Star className="w-6 h-6 text-gold" />
              <h3 className="text-lg font-semibold text-white">Product Management</h3>
            </div>
            <p className="text-gray-400 text-sm mb-4">
              Add, edit, or remove products from catalog
            </p>
            <Link
              to="/admin/products"
              className="inline-block bg-gold text-black px-4 py-2 rounded-lg hover:bg-yellow-400 transition-colors"
            >
              Manage Products
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default AdminDashboard;