import React from 'react';
import { motion } from 'framer-motion';
import { 
  RotateCcw, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  Clock, 
  Package,
  Shield,
  Phone,
  Mail,
  FileText
} from 'lucide-react';

const Returns = () => {
  const returnConditions = [
    {
      icon: CheckCircle,
      title: 'Acceptable Returns',
      color: 'text-green-400',
      bgColor: 'bg-green-400/10',
      items: [
        'Watch must be completely unworn and unused',
        'All original packaging, tags, and documentation included',
        'Protective plastic films still intact on watch and bracelet',
        'Return initiated within 4 days of delivery',
        'Watch must pass our quality inspection'
      ]
    },
    {
      icon: XCircle,
      title: 'Non-Returnable Items',
      color: 'text-red-400',
      bgColor: 'bg-red-400/10',
      items: [
        'Watches that have been worn or used',
        'Items with removed protective films or stickers',
        'Watches with scratches, marks, or signs of wear',
        'Missing original packaging or documentation',
        'Items damaged by customer misuse'
      ]
    }
  ];

  const returnProcess = [
    {
      step: 1,
      title: 'Contact Us First',
      description: 'WhatsApp us at 07361837234 within 4 days of delivery',
      time: 'Within 4 days',
      icon: Phone
    },
    {
      step: 2,
      title: 'Return Authorization',
      description: 'We will provide return instructions and authorization number',
      time: '1-2 hours',
      icon: FileText
    },
    {
      step: 3,
      title: 'Package & Send',
      description: 'Pack in original packaging and send via tracked service',
      time: 'Customer responsibility',
      icon: Package
    },
    {
      step: 4,
      title: 'Quality Inspection',
      description: 'We inspect the watch for wear, damage, or missing items',
      time: '1-2 business days',
      icon: Shield
    },
    {
      step: 5,
      title: 'Refund Decision',
      description: 'Refund processed if watch passes inspection',
      time: '3-5 business days',
      icon: CheckCircle
    }
  ];

  const importantNotes = [
    {
      icon: AlertTriangle,
      title: 'NO REFUND if watch has been opened/worn',
      description: 'Any signs of wear, removed films, or usage will result in return rejection',
      severity: 'high'
    },
    {
      icon: Clock,
      title: 'Strict 4-day return window',
      description: 'Returns must be initiated within 4 days of delivery - no exceptions',
      severity: 'high'
    },
    {
      icon: Package,
      title: 'Customer pays return shipping',
      description: 'All return shipping costs are the customer\'s responsibility',
      severity: 'medium'
    },
    {
      icon: Shield,
      title: 'Inspection required',
      description: 'All returns undergo thorough quality inspection before refund approval',
      severity: 'medium'
    }
  ];

  return (
    <div className="min-h-screen bg-navy pt-28">
      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-navy via-black to-navy">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <RotateCcw className="w-16 h-16 text-gold mx-auto mb-6" />
            <h1 className="text-4xl lg:text-5xl font-serif font-bold text-white mb-6">
              Returns & Exchanges
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Strict return policy to maintain product quality and authenticity
            </p>
          </motion.div>
        </div>
      </section>

      {/* Strict Policy Banner */}
      <section className="py-8 bg-red-900/50 border-y border-red-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-3 mb-4">
              <AlertTriangle className="w-8 h-8 text-red-400" />
              <h2 className="text-2xl font-bold text-red-300">
                STRICT RETURN POLICY
              </h2>
              <AlertTriangle className="w-8 h-8 text-red-400" />
            </div>
            <p className="text-red-200 text-lg">
              <strong>NO REFUNDS</strong> if watch has been worn, opened, or protective films removed
            </p>
            <p className="text-red-300 mt-2">
              4-day return window • Customer pays return shipping • Quality inspection required
            </p>
          </div>
        </div>
      </section>

      {/* Important Notes */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-serif font-bold text-white mb-6">
              Important Return Requirements
            </h2>
            <p className="text-xl text-gray-300">
              Please read carefully before making a purchase
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {importantNotes.map((note, index) => (
              <motion.div
                key={index}
                className={`rounded-xl border p-6 ${
                  note.severity === 'high' 
                    ? 'bg-red-900/20 border-red-700' 
                    : 'bg-yellow-900/20 border-yellow-700'
                }`}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -5 }}
              >
                <div className="flex items-start space-x-4">
                  <div className={`p-3 rounded-lg ${
                    note.severity === 'high' ? 'bg-red-400/10' : 'bg-yellow-400/10'
                  }`}>
                    <note.icon className={`w-6 h-6 ${
                      note.severity === 'high' ? 'text-red-400' : 'text-yellow-400'
                    }`} />
                  </div>
                  <div>
                    <h3 className={`text-lg font-bold mb-2 ${
                      note.severity === 'high' ? 'text-red-300' : 'text-yellow-300'
                    }`}>
                      {note.title}
                    </h3>
                    <p className="text-gray-300">{note.description}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Return Conditions */}
      <section className="py-16 bg-gradient-to-b from-black to-navy">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-serif font-bold text-white mb-6">
              Return Conditions
            </h2>
            <p className="text-xl text-gray-300">
              What we accept and what we don't
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {returnConditions.map((condition, index) => (
              <motion.div
                key={index}
                className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-8"
                initial={{ opacity: 0, x: index === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
              >
                <div className="flex items-center space-x-4 mb-6">
                  <div className={`p-3 rounded-lg ${condition.bgColor}`}>
                    <condition.icon className={`w-8 h-8 ${condition.color}`} />
                  </div>
                  <h3 className="text-2xl font-serif font-bold text-white">
                    {condition.title}
                  </h3>
                </div>

                <ul className="space-y-3">
                  {condition.items.map((item, itemIndex) => (
                    <li key={itemIndex} className="flex items-start space-x-3">
                      <div className={`w-2 h-2 rounded-full mt-2 ${
                        condition.title.includes('Acceptable') ? 'bg-green-400' : 'bg-red-400'
                      }`} />
                      <span className="text-gray-300">{item}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Return Process */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-serif font-bold text-white mb-6">
              Return Process
            </h2>
            <p className="text-xl text-gray-300">
              Follow these steps for a return request
            </p>
          </motion.div>

          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-gold via-gold to-transparent hidden lg:block" />

            <div className="space-y-12">
              {returnProcess.map((step, index) => (
                <motion.div
                  key={index}
                  className={`flex items-center ${
                    index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'
                  } flex-col lg:space-x-8`}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className={`w-full lg:w-1/2 ${index % 2 === 0 ? 'lg:pr-8 lg:text-right' : 'lg:pl-8'}`}>
                    <div className="bg-black/50 backdrop-blur-sm rounded-xl p-6 border border-gray-800">
                      <div className="flex items-center space-x-3 mb-3">
                        <div className="w-8 h-8 bg-gold text-black rounded-full flex items-center justify-center font-bold">
                          {step.step}
                        </div>
                        <step.icon className="w-6 h-6 text-gold" />
                        <h3 className="text-xl font-serif font-bold text-white">
                          {step.title}
                        </h3>
                      </div>
                      <p className="text-gray-300 mb-2">{step.description}</p>
                      <div className="text-gold font-semibold text-sm">
                        ⏱️ {step.time}
                      </div>
                    </div>
                  </div>

                  {/* Timeline Dot */}
                  <div className="relative z-10 hidden lg:block">
                    <div className="w-4 h-4 bg-gold rounded-full border-4 border-navy" />
                  </div>

                  <div className="w-full lg:w-1/2" />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Refund Information */}
      <section className="py-16 bg-gradient-to-b from-black to-navy">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-8"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="text-center mb-8">
              <Shield className="w-12 h-12 text-gold mx-auto mb-4" />
              <h2 className="text-2xl font-serif font-bold text-white mb-4">
                Refund Information
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-semibold text-gold mb-4">Refund Timeline</h3>
                <ul className="space-y-2 text-gray-300">
                  <li>• Inspection: 1-2 business days</li>
                  <li>• Refund processing: 3-5 business days</li>
                  <li>• Bank processing: 3-7 business days</li>
                  <li>• Total time: 7-14 business days</li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gold mb-4">Refund Method</h3>
                <ul className="space-y-2 text-gray-300">
                  <li>• Same payment method used for purchase</li>
                  <li>• Full purchase price (if approved)</li>
                  <li>• Shipping costs not refunded</li>
                  <li>• Return shipping paid by customer</li>
                </ul>
              </div>
            </div>

            <div className="mt-8 p-4 bg-red-900/20 border border-red-700 rounded-lg">
              <p className="text-red-300 text-sm">
                <strong>Final Decision:</strong> RDSSEIKO reserves the right to make the final decision on all returns. 
                If a watch shows any signs of wear, use, or damage, the return will be rejected and the item returned to the customer at their expense.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-gradient-to-r from-navy via-black to-navy">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-serif font-bold text-white mb-6">
              Need to Return an Item?
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Contact us first before sending anything back
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.a
                href="https://wa.me/07361837234"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-gold text-black px-8 py-4 rounded-lg font-semibold hover:bg-yellow-400 transition-colors duration-200 flex items-center justify-center space-x-2"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Phone className="w-5 h-5" />
                <span>WhatsApp: 07361837234</span>
              </motion.a>
              
              <motion.a
                href="mailto:info@rdsseiko.com"
                className="border border-gray-600 text-white px-8 py-4 rounded-lg font-semibold hover:border-gold hover:text-gold transition-colors duration-200 flex items-center justify-center space-x-2"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Mail className="w-5 h-5" />
                <span>info@rdsseiko.com</span>
              </motion.a>
            </div>

            <div className="mt-8 p-4 bg-yellow-900/20 border border-yellow-700 rounded-lg">
              <p className="text-yellow-300 text-sm">
                <strong>Remember:</strong> You must contact us within 4 days of delivery to initiate a return. 
                No exceptions will be made to this policy.
              </p>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Returns;