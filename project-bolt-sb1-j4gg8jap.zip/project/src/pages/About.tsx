import React from 'react';
import { motion } from 'framer-motion';
import { Crown, Award, Users, Globe, Clock, Shield, Heart, Star } from 'lucide-react';
import JapanFlag from '../components/Common/JapanFlag';

const About = () => {
  const stats = [
    { icon: Globe, value: '3', label: 'Countries, One Vision' },
    { icon: Users, value: 'Family', label: 'Owned & Operated' },
    { icon: Crown, value: 'London', label: 'Based Excellence' }
  ];

  const values = [
    {
      icon: Crown,
      title: 'Luxury Craftsmanship',
      description: 'Every timepiece is meticulously crafted with attention to the finest details, ensuring unparalleled quality and elegance.'
    },
    {
      icon: Shield,
      title: 'Swiss Precision',
      description: 'Our movements are engineered with Swiss precision, delivering accuracy and reliability that stands the test of time.'
    },
    {
      icon: Heart,
      title: 'Passionate Heritage',
      description: 'Born from a passion for horology, our heritage spans generations of master watchmakers and innovative design.'
    },
    {
      icon: Star,
      title: 'Innovation Excellence',
      description: 'We continuously push the boundaries of watchmaking technology while honoring traditional craftsmanship techniques.'
    }
  ];

  const timeline = [
    {
      year: 'Turkey',
      title: 'Family Origins',
      description: 'Our grandfather discovered his passion for luxury timepieces, laying the foundation for our family business.'
    },
    {
      year: 'Germany',
      title: 'European Craftsmanship',
      description: 'The family brought their vision to Germany, embracing European precision and watchmaking traditions.'
    },
    {
      year: 'London',
      title: 'Testing the Waters',
      description: 'We tested our vision in London\'s discerning luxury market, refining our approach to excellence.'
    },
    {
      year: 'Today',
      title: 'London Family Business',
      description: 'Now proudly based in London, we continue as a family business serving luxury watch enthusiasts worldwide.'
    }
  ];

  return (
    <div className="min-h-screen bg-navy pt-28">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-navy via-black to-navy opacity-90" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(212,175,55,0.1)_1px,transparent_0)] bg-[size:40px_40px]" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            className="inline-flex items-center space-x-2 bg-gold/10 border border-gold/20 rounded-full px-6 py-2 mb-8"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
          >
            <JapanFlag className="w-5 h-3" />
            <span className="text-gold font-semibold">Est. 1950</span>
          </motion.div>

          <motion.h1
            className="text-5xl lg:text-7xl font-serif font-bold text-white mb-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            Crafting
            <span className="text-gold"> Timeless </span>
            Excellence
          </motion.h1>

          <motion.p
            className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed mb-12"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            A family business with roots spanning three countries, RDSSEIKO represents generations 
            of passion for luxury timepieces. From Turkey to Germany to London, our commitment to 
            excellence has remained constant throughout our journey.
          </motion.p>

          {/* Stats */}
          <motion.div
            className="grid grid-cols-2 lg:grid-cols-4 gap-8 max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                className="text-center"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.8 + index * 0.1 }}
              >
                <stat.icon className="w-8 h-8 text-gold mx-auto mb-3" />
                <div className="text-3xl font-bold text-white mb-1">{stat.value}</div>
                <div className="text-gray-400 text-sm">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 bg-gradient-to-b from-black to-navy">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl font-serif font-bold text-white mb-6">
                Our Story
              </h2>
              <div className="space-y-6 text-gray-300 leading-relaxed">
                <p>
                  RDSSEIKO began as a family dream in Turkey, where our grandfather first 
                  discovered his passion for luxury timepieces. Seeking new opportunities, 
                  he brought this vision to Germany, where the business began to take shape 
                  with European craftsmanship and precision.
                </p>
                <p>
                  The journey continued to London, where we tested our vision in one of the 
                  world's most discerning luxury markets. It was here that RDSSEIKO truly 
                  found its home, combining international expertise with British elegance 
                  and becoming the family business we are today.
                </p>
                <p>
                  Now based in London, RDSSEIKO remains a proud family business, carrying 
                  forward generations of knowledge and passion. Every timepiece reflects 
                  our multicultural heritage and unwavering commitment to luxury and excellence.
                </p>
              </div>
            </motion.div>

            <motion.div
              className="relative"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <div className="relative rounded-2xl overflow-hidden">
                <img
                  src="/Seiko-NH35A-Mechanisches-Uhrwerk.webp"
                  alt="RDSSEIKO Craftsmanship"
                  className="w-full h-auto object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-20 bg-navy">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-serif font-bold text-white mb-6">
              Our Values
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              The principles that guide every decision we make and every timepiece we create
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={index}
                className="bg-black/50 backdrop-blur-sm rounded-xl p-8 border border-gray-800 hover:border-gold/30 transition-colors duration-300"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -5 }}
              >
                <value.icon className="w-12 h-12 text-gold mb-6" />
                <h3 className="text-xl font-serif font-bold text-white mb-4">
                  {value.title}
                </h3>
                <p className="text-gray-300 leading-relaxed">
                  {value.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-20 bg-gradient-to-b from-black to-navy">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-serif font-bold text-white mb-6">
              Our Family Journey
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              From Turkey to Germany to London - the story of our family business
            </p>
          </motion.div>

          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-gold via-gold to-transparent" />

            <div className="space-y-16">
              {timeline.map((item, index) => (
                <motion.div
                  key={index}
                  className={`flex items-center ${
                    index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'
                  }`}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className={`w-1/2 ${index % 2 === 0 ? 'pr-8 text-right' : 'pl-8'}`}>
                    <div className="bg-black/50 backdrop-blur-sm rounded-xl p-6 border border-gray-800">
                      <div className="text-xl font-bold text-gold mb-2">{item.year}</div>
                      <h3 className="text-xl font-serif font-bold text-white mb-3">
                        {item.title}
                      </h3>
                      <p className="text-gray-300 leading-relaxed">
                        {item.description}
                      </p>
                    </div>
                  </div>

                  {/* Timeline Dot */}
                  <div className="relative z-10">
                    <div className="w-4 h-4 bg-gold rounded-full border-4 border-navy" />
                  </div>

                  <div className="w-1/2" />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-gradient-to-r from-navy via-black to-navy">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <Crown className="w-16 h-16 text-gold mx-auto mb-8" />
            <h2 className="text-4xl font-serif font-bold text-white mb-6">
              Experience RDSSEIKO Excellence
            </h2>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              Discover our collection of luxury timepieces and become part of our legacy. 
              Each watch tells a story of precision, passion, and uncompromising quality.
            </p>
            <motion.a
              href="/catalog"
              className="inline-block bg-gold text-black px-8 py-4 rounded-lg font-semibold hover:bg-yellow-400 transition-colors duration-200 shadow-lg"
              whileHover={{ scale: 1.05, boxShadow: "0 10px 30px rgba(212, 175, 55, 0.3)" }}
              whileTap={{ scale: 0.95 }}
            >
              Explore Our Collection
            </motion.a>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default About;