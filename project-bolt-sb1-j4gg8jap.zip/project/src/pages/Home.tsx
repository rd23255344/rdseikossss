import React from 'react';
import Hero from '../components/Home/Hero';
import FeaturedCollections from '../components/Home/FeaturedCollections';
import Newsletter from '../components/Home/Newsletter';

const Home = () => {
  return (
    <div className="min-h-screen pt-8">
      <Hero />
      <FeaturedCollections />
      <Newsletter />
    </div>
  );
};

export default Home;