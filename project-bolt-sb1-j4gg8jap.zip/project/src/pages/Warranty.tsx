import React from 'react';
import { motion } from 'framer-motion';
import { Shield, CheckCircle, XCircle, Clock, AlertTriangle, Phone, Mail, FileText, Package, PenTool as Tool, Heart } from 'lucide-react';

const Warranty = () => {
  const coveredItems = [
    {
      icon: Tool,
      title: 'Manufacturing Defects',
      description: 'Defects in materials or workmanship that existed at the time of manufacture'
    },
    {
      icon: Clock,
      title: 'Movement Issues',
      description: 'Faulty automatic or quartz movements due to manufacturing errors'
    },
    {
      icon: Package,
      title: 'Crown Problems',
      description: 'Crown threading, winding, or setting issues caused by manufacturing defects'
    },
    {
      icon: Shield,
      title: 'Case & Bracelet Defects',
      description: 'Structural defects in case or bracelet due to poor workmanship'
    }
  ];

  const notCoveredItems = [
    {
      icon: XCircle,
      title: 'Customer Damage',
      description: 'Any damage caused by dropping, impact, or mishandling by the customer'
    },
    {
      icon: XCircle,
      title: 'Normal Wear & Tear',
      description: 'Scratches, scuffs, or normal aging from regular use over time'
    },
    {
      icon: XCircle,
      title: 'Water Damage',
      description: 'Damage from exceeding water resistance limits or improper use'
    },
    {
      icon: XCircle,
      title: 'Misuse or Abuse',
      description: 'Damage from improper handling, extreme conditions, or unauthorized repairs'
    },
    {
      icon: XCircle,
      title: 'Cosmetic Issues',
      description: 'Minor cosmetic imperfections that don\'t affect functionality'
    },
    {
      icon: XCircle,
      title: 'Battery Replacement',
      description: 'Normal battery replacement for quartz movements (not a defect)'
    }
  ];

  const warrantyProcess = [
    {
      step: 1,
      title: 'Contact Us',
      description: 'WhatsApp us at 07361837234 or email info@rdsseiko.com with your issue',
      time: 'Immediate',
      icon: Phone
    },
    {
      step: 2,
      title: 'Provide Details',
      description: 'Send photos, order number, and description of the problem',
      time: '5 minutes',
      icon: FileText
    },
    {
      step: 3,
      title: 'Assessment',
      description: 'We\'ll determine if the issue is covered under warranty',
      time: '1-2 hours',
      icon: Shield
    },
    {
      step: 4,
      title: 'Return Authorization',
      description: 'If covered, we\'ll provide return instructions and prepaid label',
      time: '2-4 hours',
      icon: Package
    },
    {
      step: 5,
      title: 'Repair/Replace',
      description: 'We\'ll repair or replace your watch at no cost to you',
      time: '3-7 days',
      icon: Tool
    }
  ];

  return (
    <div className="min-h-screen bg-navy pt-28">
      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-navy via-black to-navy">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <Shield className="w-16 h-16 text-gold mx-auto mb-6" />
            <h1 className="text-4xl lg:text-5xl font-serif font-bold text-white mb-6">
              6-Month Workmanship Warranty
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              We stand behind our craftsmanship with a comprehensive warranty covering manufacturing defects
            </p>
          </motion.div>
        </div>
      </section>

      {/* Warranty Coverage Banner */}
      <section className="py-8 bg-gold">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-black mb-2">
              🛡️ MANUFACTURING DEFECTS ONLY - OUR FAULT COVERAGE
            </h2>
            <p className="text-black">
              This warranty covers workmanship and manufacturing defects that are RDSSEIKO's responsibility
            </p>
          </div>
        </div>
      </section>

      {/* What's Covered vs Not Covered */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-serif font-bold text-white mb-6">
              Warranty Coverage Details
            </h2>
            <p className="text-xl text-gray-300">
              Understanding what is and isn't covered under our workmanship warranty
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* What's Covered */}
            <motion.div
              className="bg-green-900/20 border border-green-700 rounded-xl p-8"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <div className="flex items-center space-x-4 mb-6">
                <div className="p-3 bg-green-400/10 rounded-lg">
                  <CheckCircle className="w-8 h-8 text-green-400" />
                </div>
                <h3 className="text-2xl font-serif font-bold text-white">
                  What's Covered
                </h3>
              </div>

              <div className="space-y-6">
                {coveredItems.map((item, index) => (
                  <motion.div
                    key={index}
                    className="flex items-start space-x-4"
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    viewport={{ once: true }}
                  >
                    <div className="p-2 bg-green-400/10 rounded-lg flex-shrink-0">
                      <item.icon className="w-5 h-5 text-green-400" />
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold text-green-300 mb-1">
                        {item.title}
                      </h4>
                      <p className="text-gray-300 text-sm">{item.description}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* What's NOT Covered */}
            <motion.div
              className="bg-red-900/20 border border-red-700 rounded-xl p-8"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <div className="flex items-center space-x-4 mb-6">
                <div className="p-3 bg-red-400/10 rounded-lg">
                  <XCircle className="w-8 h-8 text-red-400" />
                </div>
                <h3 className="text-2xl font-serif font-bold text-white">
                  What's NOT Covered
                </h3>
              </div>

              <div className="space-y-6">
                {notCoveredItems.map((item, index) => (
                  <motion.div
                    key={index}
                    className="flex items-start space-x-4"
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    viewport={{ once: true }}
                  >
                    <div className="p-2 bg-red-400/10 rounded-lg flex-shrink-0">
                      <item.icon className="w-5 h-5 text-red-400" />
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold text-red-300 mb-1">
                        {item.title}
                      </h4>
                      <p className="text-gray-300 text-sm">{item.description}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Warranty Process */}
      <section className="py-16 bg-gradient-to-b from-black to-navy">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-serif font-bold text-white mb-6">
              Warranty Claim Process
            </h2>
            <p className="text-xl text-gray-300">
              Simple steps to get your watch repaired under warranty
            </p>
          </motion.div>

          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-gold via-gold to-transparent hidden lg:block" />

            <div className="space-y-12">
              {warrantyProcess.map((step, index) => (
                <motion.div
                  key={index}
                  className={`flex items-center ${
                    index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'
                  } flex-col lg:space-x-8`}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className={`w-full lg:w-1/2 ${index % 2 === 0 ? 'lg:pr-8 lg:text-right' : 'lg:pl-8'}`}>
                    <div className="bg-black/50 backdrop-blur-sm rounded-xl p-6 border border-gray-800">
                      <div className="flex items-center space-x-3 mb-3">
                        <div className="w-8 h-8 bg-gold text-black rounded-full flex items-center justify-center font-bold">
                          {step.step}
                        </div>
                        <step.icon className="w-6 h-6 text-gold" />
                        <h3 className="text-xl font-serif font-bold text-white">
                          {step.title}
                        </h3>
                      </div>
                      <p className="text-gray-300 mb-2">{step.description}</p>
                      <div className="text-gold font-semibold text-sm">
                        ⏱️ {step.time}
                      </div>
                    </div>
                  </div>

                  {/* Timeline Dot */}
                  <div className="relative z-10 hidden lg:block">
                    <div className="w-4 h-4 bg-gold rounded-full border-4 border-navy" />
                  </div>

                  <div className="w-full lg:w-1/2" />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Important Notes */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-8"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="text-center mb-8">
              <AlertTriangle className="w-12 h-12 text-yellow-400 mx-auto mb-4" />
              <h2 className="text-2xl font-serif font-bold text-white mb-4">
                Important Warranty Information
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-semibold text-gold mb-4">Warranty Period</h3>
                <ul className="space-y-2 text-gray-300 text-sm">
                  <li>• 6 months from date of purchase</li>
                  <li>• Proof of purchase required</li>
                  <li>• Warranty is non-transferable</li>
                  <li>• Covers manufacturing defects only</li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gold mb-4">Our Responsibility</h3>
                <ul className="space-y-2 text-gray-300 text-sm">
                  <li>• Free repair or replacement</li>
                  <li>• We pay return shipping (if covered)</li>
                  <li>• No labor charges for warranty work</li>
                  <li>• Quick turnaround time</li>
                </ul>
              </div>
            </div>

            <div className="mt-8 p-4 bg-yellow-900/20 border border-yellow-700 rounded-lg">
              <p className="text-yellow-300 text-sm">
                <strong>Final Decision:</strong> RDSSEIKO reserves the right to determine if an issue is covered under warranty. 
                Our technicians will assess each case individually to determine if the problem is due to manufacturing defects or other causes.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-gradient-to-r from-navy via-black to-navy">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <Heart className="w-12 h-12 text-gold mx-auto mb-6" />
            <h2 className="text-3xl font-serif font-bold text-white mb-6">
              Need Warranty Service?
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Contact us immediately if you experience any manufacturing defects
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.a
                href="https://wa.me/07361837234"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-gold text-black px-8 py-4 rounded-lg font-semibold hover:bg-yellow-400 transition-colors duration-200 flex items-center justify-center space-x-2"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Phone className="w-5 h-5" />
                <span>WhatsApp: 07361837234</span>
              </motion.a>
              
              <motion.a
                href="mailto:info@rdsseiko.com"
                className="border border-gray-600 text-white px-8 py-4 rounded-lg font-semibold hover:border-gold hover:text-gold transition-colors duration-200 flex items-center justify-center space-x-2"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Mail className="w-5 h-5" />
                <span>info@rdsseiko.com</span>
              </motion.a>
            </div>

            <div className="mt-8 p-4 bg-green-900/20 border border-green-700 rounded-lg">
              <p className="text-green-300 text-sm">
                <strong>We Care About Quality:</strong> If there's a manufacturing defect, we'll make it right. 
                Your satisfaction with our workmanship is our top priority.
              </p>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Warranty;