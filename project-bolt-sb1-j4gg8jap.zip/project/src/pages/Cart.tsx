import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ShoppingBag, 
  Plus, 
  Minus, 
  X, 
  ArrowRight,
  Heart,
  Star
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatPrice } from '../utils/currency';

const Cart = () => {
  const { state, dispatch } = useApp();

  const updateQuantity = (id: string, quantity: number) => {
    if (quantity <= 0) {
      dispatch({ type: 'REMOVE_FROM_CART', payload: id });
    } else {
      dispatch({ type: 'UPDATE_CART_QUANTITY', payload: { id, quantity } });
    }
  };

  const removeItem = (id: string) => {
    dispatch({ type: 'REMOVE_FROM_CART', payload: id });
  };

  const subtotal = state.cart.reduce((sum, item) => sum + (item.watch.price * item.quantity), 0);
  
  // Location-based shipping costs
  const getShippingCost = () => {
    // For cart page, show UK domestic rate as default
    // In checkout, this will be calculated based on selected country
    return 2; // £2 for UK (default)
  };
  
  const shipping = getShippingCost();
  const total = subtotal + shipping;

  if (state.cart.length === 0) {
    return (
      <div className="min-h-screen bg-navy pt-28">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <motion.div
            className="text-center"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <ShoppingBag className="w-24 h-24 text-gray-600 mx-auto mb-8" />
            <h1 className="text-4xl font-serif font-bold text-white mb-4">
              Your Cart is Empty
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Discover our collection of luxury timepieces
            </p>
            <Link
              to="/catalog"
              className="inline-block bg-gold text-black px-8 py-4 rounded-lg font-semibold hover:bg-yellow-400 transition-colors"
            >
              Shop Now
            </Link>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-navy pt-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          className="mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-3xl lg:text-4xl font-serif font-bold text-white mb-2">
            Shopping Cart
          </h1>
          <p className="text-gray-400">
            {state.cart.reduce((sum, item) => sum + item.quantity, 0)} item{state.cart.length !== 1 ? 's' : ''} in your cart
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <motion.div
              className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <div className="space-y-6">
                {state.cart.map((item, index) => (
                  <motion.div
                    key={item.watch.id}
                    className="flex flex-col md:flex-row items-start md:items-center space-y-4 md:space-y-0 md:space-x-6 p-4 bg-gray-900/50 rounded-lg"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                  >
                    {/* Image */}
                    <Link to={`/product/${item.watch.id}`} className="flex-shrink-0">
                      <img
                        src={item.watch.image}
                        alt={item.watch.name}
                        className="w-24 h-24 object-cover rounded-lg hover:scale-105 transition-transform duration-200"
                      />
                    </Link>

                    {/* Details */}
                    <div className="flex-1 min-w-0">
                      <Link to={`/product/${item.watch.id}`}>
                        <p className="text-gold text-sm font-semibold">{item.watch.collection}</p>
                        <h3 className="text-lg font-serif font-bold text-white hover:text-gold transition-colors">
                          {item.watch.name}
                        </h3>
                      </Link>
                      
                      {/* Rating */}
                      <div className="flex items-center gap-2 mt-2">
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-3 h-3 ${
                                i < Math.floor(item.watch.rating) 
                                  ? 'text-gold fill-gold' 
                                  : 'text-gray-600'
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-xs text-gray-400">
                          ({item.watch.reviewCount})
                        </span>
                      </div>

                      {/* Specifications */}
                      <div className="text-xs text-gray-400 mt-2 space-y-1">
                        <div>Movement: {item.watch.specifications.movement}</div>
                        <div>Case: {item.watch.specifications.caseMaterial}</div>
                      </div>
                    </div>

                    {/* Price & Quantity */}
                    <div className="flex flex-col items-end space-y-4">
                      <div className="text-right">
                        <div className="text-xl font-bold text-white">
                          {formatPrice(item.watch.price, state.currency)}
                        </div>
                        <div className="text-sm text-gray-400">per item</div>
                      </div>

                      {/* Quantity Controls */}
                      <div className="flex items-center bg-gray-800 rounded-lg">
                        <button
                          onClick={() => updateQuantity(item.watch.id, item.quantity - 1)}
                          className="p-2 text-white hover:text-gold transition-colors"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="px-4 py-2 text-white font-semibold min-w-[3rem] text-center">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.watch.id, item.quantity + 1)}
                          className="p-2 text-white hover:text-gold transition-colors"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Total Price */}
                      <div className="text-lg font-bold text-gold">
                        {formatPrice(item.watch.price * item.quantity, state.currency)}
                      </div>

                      {/* Remove Button */}
                      <button
                        onClick={() => removeItem(item.watch.id)}
                        className="text-red-400 hover:text-red-300 transition-colors p-1"
                        title="Remove from cart"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <motion.div
              className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6 sticky top-32"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <h2 className="text-xl font-serif font-bold text-white mb-6">
                Order Summary
              </h2>

              <div className="space-y-4 mb-6">
                <div className="flex justify-between text-gray-300">
                  <span>Subtotal ({state.cart.reduce((sum, item) => sum + item.quantity, 0)} items)</span>
                  <span>{formatPrice(subtotal, state.currency)}</span>
                </div>
                
                <div className="flex justify-between text-gray-300">
                  <span>Shipping</span>
                  <span>{formatPrice(shipping, state.currency)}</span>
                </div>
                
                <div className="border-t border-gray-700 pt-4">
                  <div className="flex justify-between text-xl font-bold">
                    <span className="text-white">Total</span>
                    <span className="text-gold">{formatPrice(total, state.currency)}</span>
                  </div>
                </div>
              </div>

              {/* Free Shipping Notice */}
              <div className="bg-blue-900/20 border border-blue-700 rounded-lg p-3 mb-6">
                <p className="text-blue-300 text-sm">
                  UK Shipping: £2 | International rates vary by destination
                </p>
              </div>

              {/* Checkout Button */}
              <Link to="/checkout">
                <motion.button
                  className="w-full bg-gold text-black py-4 rounded-lg font-semibold hover:bg-yellow-400 transition-colors duration-200 flex items-center justify-center space-x-2"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <span>Proceed to Checkout</span>
                  <ArrowRight className="w-5 h-5" />
                </motion.button>
              </Link>

              {/* Continue Shopping */}
              <Link
                to="/catalog"
                className="block w-full text-center border border-gray-600 text-white py-3 rounded-lg font-semibold hover:border-gold hover:text-gold transition-colors mt-4"
              >
                Continue Shopping
              </Link>

              {/* Security Features */}
              <div className="mt-6 pt-6 border-t border-gray-700">
                <div className="text-center text-xs text-gray-400 space-y-2">
                  <div>🔒 Secure Checkout</div>
                  <div>🚚 Fast Shipping</div>
                  <div>🛡️ 6 Month Warranty</div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;