import React from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Plus, Minus, ShoppingBag } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { formatPrice } from '../../utils/currency';

const CartSidebar = () => {
  const { state, dispatch } = useApp();

  const updateQuantity = (id: string, quantity: number) => {
    if (quantity <= 0) {
      dispatch({ type: 'REMOVE_FROM_CART', payload: id });
    } else {
      dispatch({ type: 'UPDATE_CART_QUANTITY', payload: { id, quantity } });
    }
  };

  const total = state.cart.reduce((sum, item) => sum + (item.watch.price * item.quantity), 0);

  return (
    <AnimatePresence>
      {state.isCartOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            className="fixed inset-0 bg-black/50 z-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => dispatch({ type: 'SET_CART_OPEN', payload: false })}
          />

          {/* Cart Sidebar */}
          <motion.div
            className="fixed top-0 right-0 h-full w-full max-w-md bg-navy border-l border-gray-800 z-50 overflow-hidden"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'tween', duration: 0.3 }}
          >
            <div className="flex flex-col h-full">
              {/* Header */}
              <div className="flex items-center justify-between p-6 border-b border-gray-800">
                <h2 className="text-xl font-serif font-bold text-white">
                  Shopping Cart ({state.cart.reduce((sum, item) => sum + item.quantity, 0)})
                </h2>
                <button
                  onClick={() => dispatch({ type: 'SET_CART_OPEN', payload: false })}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Cart Items */}
              <div className="flex-1 overflow-y-auto">
                {state.cart.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-center p-6">
                    <ShoppingBag className="w-16 h-16 text-gray-600 mb-4" />
                    <h3 className="text-lg font-semibold text-white mb-2">Your cart is empty</h3>
                    <p className="text-gray-400 mb-6">Add some luxury timepieces to get started</p>
                    <Link
                      to="/catalog"
                      onClick={() => dispatch({ type: 'SET_CART_OPEN', payload: false })}
                      className="bg-gold text-black px-6 py-3 rounded-lg font-semibold hover:bg-yellow-400 transition-colors"
                    >
                      Shop Now
                    </Link>
                  </div>
                ) : (
                  <div className="p-6 space-y-4">
                    {state.cart.map((item) => (
                      <motion.div
                        key={item.watch.id}
                        className="flex items-center space-x-4 bg-black/50 rounded-lg p-4"
                        layout
                      >
                        {/* Image */}
                        <img
                          src={item.watch.image}
                          alt={item.watch.name}
                          className="w-16 h-16 object-cover rounded-lg"
                        />

                        {/* Details */}
                        <div className="flex-1">
                          <h4 className="font-semibold text-white text-sm">{item.watch.name}</h4>
                          <p className="text-gold text-sm">${item.watch.price.toLocaleString()}</p>
                        </div>

                        {/* Quantity Controls */}
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => updateQuantity(item.watch.id, item.quantity - 1)}
                            className="p-1 rounded-full bg-gray-800 text-white hover:bg-gray-700"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-white font-semibold w-8 text-center">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.watch.id, item.quantity + 1)}
                            className="p-1 rounded-full bg-gray-800 text-white hover:bg-gray-700"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        {/* Remove */}
                        <button
                          onClick={() => dispatch({ type: 'REMOVE_FROM_CART', payload: item.watch.id })}
                          className="text-gray-400 hover:text-red-400 transition-colors"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>

              {/* Footer */}
              {state.cart.length > 0 && (
                <div className="border-t border-gray-800 p-6 space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-semibold text-white">Total:</span>
                    <span className="text-2xl font-bold text-gold">{formatPrice(total, state.currency)}</span>
                  </div>
                  
                  <div className="space-y-3">
                    <Link
                      to="/cart"
                      onClick={() => dispatch({ type: 'SET_CART_OPEN', payload: false })}
                      className="block w-full bg-gold text-black text-center py-3 rounded-lg font-semibold hover:bg-yellow-400 transition-colors"
                    >
                      View Cart
                    </Link>
                    <Link
                      to="/checkout"
                      onClick={() => dispatch({ type: 'SET_CART_OPEN', payload: false })}
                      className="block w-full border border-gray-600 text-white text-center py-3 rounded-lg font-semibold hover:border-gold hover:text-gold transition-colors"
                    >
                      Checkout
                    </Link>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default CartSidebar;