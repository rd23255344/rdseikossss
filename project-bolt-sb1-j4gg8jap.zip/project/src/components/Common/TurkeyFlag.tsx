import React from 'react';

const TurkeyFlag = ({ className = "w-6 h-4" }: { className?: string }) => {
  return (
    <svg
      className={className}
      viewBox="0 0 24 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Red background */}
      <rect x="0" y="0" width="24" height="16" fill="#E30A17" />
      
      {/* White crescent */}
      <circle cx="7" cy="8" r="3.5" fill="#FFFFFF" />
      <circle cx="8.5" cy="8" r="2.8" fill="#E30A17" />
      
      {/* White star */}
      <polygon 
        points="13,5.5 13.8,7.8 16.2,7.8 14.2,9.2 15,11.5 13,10.1 11,11.5 11.8,9.2 9.8,7.8 12.2,7.8" 
        fill="#FFFFFF" 
      />
      
      {/* Border */}
      <rect x="0" y="0" width="24" height="16" fill="none" stroke="#E0E0E0" strokeWidth="0.5" />
    </svg>
  );
};

export default TurkeyFlag;