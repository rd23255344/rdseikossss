import React from 'react';

const UAEFlag = ({ className = "w-6 h-4" }: { className?: string }) => {
  return (
    <svg
      className={className}
      viewBox="0 0 24 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Red vertical stripe */}
      <rect x="0" y="0" width="8" height="16" fill="#FF0000" />
      
      {/* Green horizontal stripe */}
      <rect x="8" y="0" width="16" height="5.33" fill="#00843D" />
      
      {/* White horizontal stripe */}
      <rect x="8" y="5.33" width="16" height="5.33" fill="#FFFFFF" />
      
      {/* Black horizontal stripe */}
      <rect x="8" y="10.67" width="16" height="5.33" fill="#000000" />
    </svg>
  );
};

export default UAEFlag;