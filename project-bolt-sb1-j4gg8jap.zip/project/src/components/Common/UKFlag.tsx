import React from 'react';

const UKFlag = ({ className = "w-6 h-4" }: { className?: string }) => {
  return (
    <svg
      className={className}
      viewBox="0 0 24 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Blue background */}
      <rect x="0" y="0" width="24" height="16" fill="#012169" />
      
      {/* White diagonal cross (St. Patrick's cross background) */}
      <polygon points="0,0 2.4,0 24,14.4 24,16 21.6,16 0,1.6" fill="#FFFFFF" />
      <polygon points="0,16 0,14.4 21.6,0 24,0 24,1.6 2.4,16" fill="#FFFFFF" />
      
      {/* Red diagonal cross (St. Patrick's cross) */}
      <polygon points="0,0 1.2,0 24,15.2 24,16 22.8,16 0,0.8" fill="#C8102E" />
      <polygon points="0,16 0,15.2 22.8,0 24,0 24,0.8 1.2,16" fill="#C8102E" />
      
      {/* White cross (St. George's cross background) */}
      <rect x="0" y="6" width="24" height="4" fill="#FFFFFF" />
      <rect x="10" y="0" width="4" height="16" fill="#FFFFFF" />
      
      {/* Red cross (St. George's cross) */}
      <rect x="0" y="7" width="24" height="2" fill="#C8102E" />
      <rect x="11" y="0" width="2" height="16" fill="#C8102E" />
      
      {/* Border */}
      <rect x="0" y="0" width="24" height="16" fill="none" stroke="#E0E0E0" strokeWidth="0.5" />
    </svg>
  );
};

export default UKFlag;