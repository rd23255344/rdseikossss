import React from 'react';

const JapanFlag = ({ className = "w-6 h-4" }: { className?: string }) => {
  return (
    <svg
      className={className}
      viewBox="0 0 24 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* White background */}
      <rect x="0" y="0" width="24" height="16" fill="#FFFFFF" />
      
      {/* Red circle (sun) */}
      <circle cx="12" cy="8" r="4.8" fill="#BC002D" />
      
      {/* Border */}
      <rect x="0" y="0" width="24" height="16" fill="none" stroke="#E0E0E0" strokeWidth="0.5" />
    </svg>
  );
};

export default JapanFlag;