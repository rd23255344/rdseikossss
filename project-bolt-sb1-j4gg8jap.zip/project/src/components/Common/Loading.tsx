import React from 'react';
import { motion } from 'framer-motion';
import { Crown } from 'lucide-react';

const Loading = () => {
  return (
    <div className="min-h-screen bg-navy flex items-center justify-center">
      <div className="text-center">
        <motion.div
          className="flex items-center justify-center space-x-3 text-4xl font-serif font-bold mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Crown className="w-10 h-10 text-gold" />
          <div>
            <span className="text-gold">RDS</span>
            <span className="text-white">SEIKO</span>
          </div>
        </motion.div>
        
        <div className="flex justify-center space-x-2">
          {[0, 1, 2].map((index) => (
            <motion.div
              key={index}
              className="w-3 h-3 bg-gold rounded-full"
              initial={{ scale: 0.5, opacity: 0.3 }}
              animate={{ 
                scale: [0.5, 1, 0.5], 
                opacity: [0.3, 1, 0.3] 
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                delay: index * 0.2
              }}
            />
          ))}
        </div>
        
        <motion.p
          className="text-gray-400 mt-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
        >
          Loading luxury timepieces...
        </motion.p>
      </div>
    </div>
  );
};

export default Loading;