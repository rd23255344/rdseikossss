import React from 'react';
import { motion } from 'framer-motion';
import { Shield, RotateCcw, Heart } from 'lucide-react';

const WarrantyBanner = () => {
  return (
    <div className="bg-gold text-black py-2 overflow-hidden relative">
      <motion.div
        className="flex items-center justify-center space-x-4 whitespace-nowrap"
        animate={{ x: [0, -100, 0] }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "linear"
        }}
      >
        <div className="flex items-center space-x-2 font-semibold text-sm">
          <Shield className="w-4 h-4" />
          <span>6 MONTH WORKMANSHIP WARRANTY</span>
        </div>
        <span className="text-black/60">•</span>
        <div className="flex items-center space-x-2 font-semibold text-sm">
          <Heart className="w-4 h-4" />
          <span>DUBAI FAVOURITE</span>
        </div>
        <span className="text-black/60">•</span>
        <div className="flex items-center space-x-2 font-semibold text-sm">
          <RotateCcw className="w-4 h-4" />
          <span>RETURNS ACCEPTED</span>
        </div>
        <span className="text-black/60">•</span>
        <div className="flex items-center space-x-2 font-semibold text-sm">
          <Shield className="w-4 h-4" />
          <span>6 MONTH WORKMANSHIP WARRANTY</span>
        </div>
        <span className="text-black/60">•</span>
        <div className="flex items-center space-x-2 font-semibold text-sm">
          <Heart className="w-4 h-4" />
          <span>DUBAI FAVOURITE</span>
        </div>
        <span className="text-black/60">•</span>
        <div className="flex items-center space-x-2 font-semibold text-sm">
          <RotateCcw className="w-4 h-4" />
          <span>RETURNS ACCEPTED</span>
        </div>
        <span className="text-black/60">•</span>
        <div className="flex items-center space-x-2 font-semibold text-sm">
          <Shield className="w-4 h-4" />
          <span>6 MONTH WORKMANSHIP WARRANTY</span>
        </div>
        <span className="text-black/60">•</span>
        <div className="flex items-center space-x-2 font-semibold text-sm">
          <Heart className="w-4 h-4" />
          <span>DUBAI FAVOURITE</span>
        </div>
        <span className="text-black/60">•</span>
        <div className="flex items-center space-x-2 font-semibold text-sm">
          <RotateCcw className="w-4 h-4" />
          <span>RETURNS ACCEPTED</span>
        </div>
        <span className="text-black/60">•</span>
        <div className="flex items-center space-x-2 font-semibold text-sm">
          <Shield className="w-4 h-4" />
          <span>6 MONTH WORKMANSHIP WARRANTY</span>
        </div>
      </motion.div>
    </div>
  );
};

export default WarrantyBanner;