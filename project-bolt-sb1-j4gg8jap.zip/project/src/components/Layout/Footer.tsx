import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Mail, 
  Phone, 
  Facebook, 
  Twitter, 
  Instagram, 
  Youtube,
  Crown,
  Heart
} from 'lucide-react';
import TurkeyFlag from '../Common/TurkeyFlag';
import UKFlag from '../Common/UKFlag';

const Footer = () => {
  return (
    <footer className="bg-black text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Content */}
        <div className="py-12 lg:py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Brand Section */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="col-span-1 md:col-span-2 lg:col-span-1"
            >
              <div className="flex items-center space-x-2 text-3xl font-serif font-bold mb-4">
                <Crown className="w-8 h-8 text-gold" />
                <div>
                  <span className="text-gold">RDS</span>SEIKO
                </div>
              </div>
              <p className="text-gray-400 mb-6 leading-relaxed">
                Crafting exceptional timepieces since 1950. Our commitment to precision, 
                luxury, and innovation has made us a trusted name in horology worldwide.
              </p>
              
              {/* Social Media */}
              <div className="flex space-x-4">
                {[
                  { icon: Facebook, href: '#' },
                  { icon: Twitter, href: '#' },
                  { icon: Instagram, href: '#' },
                  { icon: Youtube, href: '#' }
                ].map((social, index) => (
                  <motion.a
                    key={index}
                    href={social.href}
                    className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center text-gray-400 hover:bg-gold hover:text-black transition-colors duration-200"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <social.icon className="w-5 h-5" />
                  </motion.a>
                ))}
              </div>
            </motion.div>

            {/* Quick Links */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <h3 className="text-lg font-semibold mb-6 text-gold">Quick Links</h3>
              <ul className="space-y-3">
                {[
                  { name: 'Home', href: '/' },
                  { name: 'All Watches', href: '/catalog' },
                  { name: 'Men\'s Collection', href: '/catalog?category=mens' },
                  { name: 'About Us', href: '/about' }
                ].map((link, index) => (
                  <li key={index}>
                    <Link 
                      to={link.href}
                      className="text-gray-400 hover:text-gold transition-colors duration-200"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </motion.div>

            {/* Customer Service */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <h3 className="text-lg font-semibold mb-6 text-gold">Customer Service</h3>
              <ul className="space-y-3">
                {[
                  { name: 'FAQ', href: '/faq' },
                  { name: 'Shipping Info', href: '/shipping' },
                  { name: 'Returns & Exchanges', href: '/returns' },
                  { name: 'Warranty', href: '/warranty' },
                  { name: 'Contact Support', href: '/contact' }
                ].map((link, index) => (
                  <li key={index}>
                    <Link 
                      to={link.href}
                      className="text-gray-400 hover:text-gold transition-colors duration-200"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </motion.div>

            {/* Contact Info */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <h3 className="text-lg font-semibold mb-6 text-gold">Contact Info</h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Phone className="w-5 h-5 text-gold flex-shrink-0" />
                  <span className="text-gray-400">WhatsApp: 07361837234</span>
                </div>
                
                <div className="flex items-center space-x-3">
                  <Mail className="w-5 h-5 text-gold flex-shrink-0" />
                  <span className="text-gray-400">info@rdsseiko.com</span>
                </div>
              </div>

              {/* Newsletter */}
              <div className="mt-8">
                <h4 className="text-sm font-semibold mb-3 text-silver">Stay Updated</h4>
                <form className="space-y-3">
                  <input
                    type="email"
                    placeholder="Your email address"
                    className="w-full bg-gray-900 text-white placeholder-gray-500 rounded-lg px-4 py-2 border border-gray-700 focus:border-gold focus:outline-none text-sm"
                  />
                  <motion.button
                    type="submit"
                    className="w-full bg-gold text-black py-2 rounded-lg font-semibold hover:bg-yellow-500 transition-colors duration-200 text-sm"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    Subscribe
                  </motion.button>
                </form>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
            <div className="text-gray-400 text-sm text-center md:text-left">
              © 2025 RDSSEIKO. All rights reserved. | Privacy Policy | Terms of Service
            </div>
            
            <div className="flex items-center space-x-6 text-sm text-gray-400">
              <span>Secure Payment</span>
              <span>•</span>
              <span>INTERNATIONAL SHIPPING</span>
              <span>•</span>
              <span>6 MONTH WORKMANSHIP WARRANTY (OUR FAULT ONLY)</span>
            </div>
          </div>
          
          {/* Flags and Heart Section */}
          <div className="flex items-center justify-center space-x-4 mt-6 pt-4 border-t border-gray-800">
            <motion.div
              className="flex items-center space-x-2"
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <TurkeyFlag className="w-6 h-4" />
              <span className="text-gray-400 text-sm">→</span>
              <div className="w-6 h-4 bg-gray-700 rounded-sm flex items-center justify-center">
                <span className="text-xs">🇩🇪</span>
              </div>
              <span className="text-gray-400 text-sm">→</span>
              <UKFlag className="w-6 h-4" />
              <span className="text-gray-400 text-sm mx-3">•</span>
              <Heart className="w-5 h-5 text-red-500 fill-red-500" />
              <span className="text-gray-400 text-sm">Made with love</span>
            </motion.div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;