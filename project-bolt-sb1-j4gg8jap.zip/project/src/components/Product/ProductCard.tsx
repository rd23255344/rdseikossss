import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heart, ShoppingBag, Star, Eye, Info } from 'lucide-react';
import { Watch } from '../../types';
import { useApp } from '../../context/AppContext';

interface ProductCardProps {
  watch: Watch;
  viewMode?: 'grid' | 'list';
  onSpecsClick?: (watch: Watch) => void;
}

const ProductCard = ({ watch, viewMode = 'grid', onSpecsClick }: ProductCardProps) => {
  const { state, dispatch } = useApp();
  const isInWishlist = state.wishlist.includes(watch.id);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dispatch({ type: 'ADD_TO_CART', payload: watch });
  };

  const handleToggleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dispatch({ type: 'TOGGLE_WISHLIST', payload: watch.id });
  };

  const handleSpecsClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (onSpecsClick) {
      onSpecsClick(watch);
    }
  };

  if (viewMode === 'list') {
    return (
      <motion.div
        className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 overflow-hidden hover:border-gold/30 transition-colors duration-300"
        whileHover={{ y: -2 }}
        transition={{ duration: 0.3 }}
      >
        <Link to={`/product/${watch.id}`}>
          <div className="flex flex-col md:flex-row">
            {/* Image */}
            <div className="relative w-full md:w-64 h-64 overflow-hidden">
              <img
                src={watch.image}
                alt={watch.name}
                className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
              />
              
              {/* Badges */}
              <div className="absolute top-3 left-3 flex flex-col gap-2">
                {watch.isNew && (
                  <span className="bg-gold text-black px-2 py-1 rounded-full text-xs font-bold">
                    NEW
                  </span>
                )}
                {watch.isBestseller && (
                  <span className="bg-silver text-black px-2 py-1 rounded-full text-xs font-bold">
                    BESTSELLER
                  </span>
                )}
              </div>

              {/* Quick Actions */}
              <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 p-6 flex flex-col justify-between">
              <div>
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="text-gold text-sm font-semibold">{watch.collection}</p>
                    <h3 className="text-xl font-serif font-bold text-white mb-2">
                      {watch.name}
                    </h3>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-2xl font-bold text-white mb-1">
                      ${watch.price.toLocaleString()}
                    </div>
                    {watch.originalPrice && (
                      <div className="text-sm text-gray-400 line-through">
                        ${watch.originalPrice.toLocaleString()}
                      </div>
                    )}
                  </div>
                </div>

                <p className="text-gray-300 text-sm mb-4 leading-relaxed">
                  {watch.description}
                </p>

                {/* Rating */}
                <div className="flex items-center gap-2 mb-4">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${
                          i < Math.floor(watch.rating) 
                            ? 'text-gold fill-gold' 
                            : 'text-gray-600'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-gray-400">
                    {watch.rating} ({watch.reviewCount} reviews)
                  </span>
                </div>

                {/* Specifications */}
                <div className="text-xs text-gray-400 space-y-1">
                  <div>Movement: {watch.specifications.movement}</div>
                  <div>Case: {watch.specifications.caseMaterial}</div>
                  <div>Diameter: {watch.specifications.diameter}</div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-3 mt-4">
                <motion.button
                  onClick={handleAddToCart}
                  className="flex-1 bg-gold text-black py-2 px-4 rounded-lg font-semibold hover:bg-yellow-400 transition-colors duration-200"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Add to Cart
                </motion.button>
                
                <button className="p-2 border border-gray-600 text-gray-400 rounded-lg hover:border-gold hover:text-gold transition-colors duration-200">
                  <Eye className="w-5 h-5" />
                </button>
                
                {onSpecsClick && (
                  <motion.button
                    onClick={(e) => {
                      e.preventDefault();
                      onSpecsClick(watch);
                    }}
                    className="p-2 border border-gray-600 text-gray-400 rounded-lg hover:border-gold hover:text-gold transition-colors duration-200"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Info className="w-5 h-5" />
                  </motion.button>
                )}
              </div>
            </div>
          </div>
        </Link>
      </motion.div>
    );
  }

  return (
    <motion.div
      className="group bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 overflow-hidden hover:border-gold/30 transition-all duration-300"
      whileHover={{ y: -5 }}
      transition={{ duration: 0.3 }}
      onClick={onSpecsClick ? () => onSpecsClick(watch) : undefined}
      style={{ cursor: onSpecsClick ? 'pointer' : 'default' }}
    >
        {/* Image */}
        <div className="relative aspect-square overflow-hidden">
          <img
            src={watch.image}
            alt={watch.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
          
          {/* Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-2">
            {watch.isNew && (
              <motion.span
                className="bg-gold text-black px-3 py-1 rounded-full text-xs font-bold"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.3 }}
              >
                NEW
              </motion.span>
            )}
            {watch.isBestseller && (
              <motion.span
                className="bg-silver text-black px-3 py-1 rounded-full text-xs font-bold"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.3, delay: 0.1 }}
              >
                BESTSELLER
              </motion.span>
            )}
          </div>

          {/* Quick Actions */}
          <div className="absolute top-3 right-3 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <motion.button
              onClick={handleToggleWishlist}
              className={`p-2 rounded-full backdrop-blur-sm border ${
                isInWishlist 
                  ? 'bg-gold text-black border-gold' 
                  : 'bg-black/50 text-white border-gray-600 hover:border-gold'
              } transition-colors duration-200`}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Heart className={`w-4 h-4 ${isInWishlist ? 'fill-current' : ''}`} />
            </motion.button>

            <Link to={`/product/${watch.id}`}>
              <motion.button
                className="p-2 rounded-full bg-black/50 text-white border border-gray-600 hover:border-gold transition-colors duration-200"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={(e) => e.stopPropagation()}
              >
                <Eye className="w-4 h-4" />
              </motion.button>
            </Link>

            {onSpecsClick && (
              <motion.button
                onClick={handleSpecsClick}
                className="p-2 rounded-full bg-black/50 text-white border border-gray-600 hover:border-gold transition-colors duration-200"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <Info className="w-4 h-4" />
              </motion.button>
            )}
          </div>

          {/* Quick Add to Cart */}
          <motion.div
            className="absolute bottom-3 left-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
            initial={{ y: 20 }}
            whileHover={{ y: 0 }}
          >
            <motion.button
              onClick={handleAddToCart}
              className="w-full bg-gold text-black py-2 rounded-lg font-semibold hover:bg-yellow-400 transition-colors duration-200 backdrop-blur-sm"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <ShoppingBag className="w-4 h-4 inline mr-2" />
              Add to Cart
            </motion.button>
          </motion.div>
        </div>

        {/* Content */}
        <div className="p-6">
          <div className="mb-2">
            <p className="text-gold text-sm font-semibold">{watch.collection}</p>
            <Link to={`/product/${watch.id}`}>
              <h3 className="text-lg font-serif font-bold text-white group-hover:text-gold transition-colors duration-200 hover:underline">
                {watch.name}
              </h3>
            </Link>
          </div>

          {/* Rating */}
          <div className="flex items-center gap-2 mb-3">
            <div className="flex items-center">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-3 h-3 ${
                    i < Math.floor(watch.rating) 
                      ? 'text-gold fill-gold' 
                      : 'text-gray-600'
                  }`}
                />
              ))}
            </div>
            <span className="text-xs text-gray-400">
              ({watch.reviewCount})
            </span>
          </div>

          {/* Price */}
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xl font-bold text-white">
                ${watch.price.toLocaleString()}
              </div>
              {watch.originalPrice && (
                <div className="text-sm text-gray-400 line-through">
                  ${watch.originalPrice.toLocaleString()}
                </div>
              )}
            </div>

            {watch.inStock ? (
              <span className="text-xs text-green-400 font-semibold">In Stock</span>
            ) : (
              <span className="text-xs text-red-400 font-semibold">Out of Stock</span>
            )}
          </div>
        </div>
    </motion.div>
  );
};

export default ProductCard;