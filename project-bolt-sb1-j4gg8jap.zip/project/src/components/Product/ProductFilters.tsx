import React from 'react';
import { motion } from 'framer-motion';
import { useApp } from '../../context/AppContext';

const ProductFilters = () => {
  const { state, dispatch } = useApp();

  const categories = [
    { value: 'all', label: 'All Watches' },
    { value: 'mens', label: "Men's" },
    { value: 'womens', label: "Women's" },
    { value: 'luxury', label: 'Luxury' },
    { value: 'sport', label: 'Sport' },
  ];

  const sortOptions = [
    { value: 'newest', label: 'Newest First' },
    { value: 'price-low', label: 'Price: Low to High' },
    { value: 'price-high', label: 'Price: High to Low' },
    { value: 'rating', label: 'Highest Rated' },
    { value: 'bestseller', label: 'Bestsellers' },
  ];

  const handleCategoryChange = (category: string) => {
    dispatch({ type: 'SET_FILTER', payload: { category } });
  };

  const handlePriceRangeChange = (min: number, max: number) => {
    dispatch({ type: 'SET_FILTER', payload: { priceRange: [min, max] } });
  };

  const handleSortChange = (sortBy: string) => {
    dispatch({ type: 'SET_FILTER', payload: { sortBy } });
  };

  const handleResetFilters = () => {
    dispatch({ type: 'RESET_FILTERS' });
  };

  return (
    <motion.div
      className="bg-black/50 backdrop-blur-sm rounded-xl border border-gray-800 p-6"
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.6 }}
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-white">Filters</h3>
        <button
          onClick={handleResetFilters}
          className="text-sm text-gold hover:text-yellow-400 transition-colors"
        >
          Reset Filters
        </button>
      </div>

      {/* Category Filter */}
      <div className="mb-6">
        <h4 className="text-sm font-semibold text-white mb-3">Category</h4>
        <div className="space-y-2">
          {categories.map((category) => (
            <label key={category.value} className="flex items-center cursor-pointer">
              <input
                type="radio"
                name="category"
                value={category.value}
                checked={state.filters.category === category.value}
                onChange={() => handleCategoryChange(category.value)}
                className="sr-only"
              />
              <div className={`w-4 h-4 rounded-full border-2 mr-3 flex items-center justify-center ${
                state.filters.category === category.value
                  ? 'border-gold bg-gold'
                  : 'border-gray-600'
              }`}>
                {state.filters.category === category.value && (
                  <div className="w-2 h-2 rounded-full bg-black" />
                )}
              </div>
              <span className={`text-sm ${
                state.filters.category === category.value ? 'text-gold' : 'text-gray-300'
              }`}>
                {category.label}
              </span>
            </label>
          ))}
        </div>
      </div>

      {/* Price Range Filter */}
      <div className="mb-6">
        <h4 className="text-sm font-semibold text-white mb-3">Price Range</h4>
        <div className="space-y-4">
          <div className="flex items-center justify-between text-sm text-gray-300">
            <span>${state.filters.priceRange[0]}</span>
            <span>${state.filters.priceRange[1]}</span>
          </div>
          
          {/* Min Price Slider */}
          <div>
            <label className="text-xs text-gray-400 mb-1 block">Min Price</label>
            <input
              type="range"
              min="0"
              max="250"
              step="10"
              value={state.filters.priceRange[0]}
              onChange={(e) => handlePriceRangeChange(
                parseInt(e.target.value),
                state.filters.priceRange[1]
              )}
              className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
            />
          </div>

          {/* Max Price Slider */}
          <div>
            <label className="text-xs text-gray-400 mb-1 block">Max Price</label>
            <input
              type="range"
              min="0"
              max="250"
              step="10"
              value={state.filters.priceRange[1]}
              onChange={(e) => handlePriceRangeChange(
                state.filters.priceRange[0],
                parseInt(e.target.value)
              )}
              className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
            />
          </div>

          <div className="text-center text-sm text-gray-300 bg-gray-800 rounded-lg py-2">
            ${state.filters.priceRange[0]} - ${state.filters.priceRange[1]}
          </div>
        </div>
      </div>

      {/* Sort Filter */}
      <div className="mb-6">
        <h4 className="text-sm font-semibold text-white mb-3">Sort By</h4>
        <select
          value={state.filters.sortBy}
          onChange={(e) => handleSortChange(e.target.value)}
          className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-white focus:border-gold focus:outline-none"
        >
          {sortOptions.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </div>

      <style jsx>{`
        .slider::-webkit-slider-thumb {
          appearance: none;
          height: 20px;
          width: 20px;
          border-radius: 50%;
          background: #d4af37;
          cursor: pointer;
          border: 2px solid #000;
        }

        .slider::-moz-range-thumb {
          height: 20px;
          width: 20px;
          border-radius: 50%;
          background: #d4af37;
          cursor: pointer;
          border: 2px solid #000;
        }
      `}</style>
    </motion.div>
  );
};

export default ProductFilters;