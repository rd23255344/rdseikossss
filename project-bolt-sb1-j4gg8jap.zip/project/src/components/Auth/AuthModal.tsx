import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Eye, EyeOff, CheckCircle, AlertCircle } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { signUp, signIn } from '../../services/authService';

const AuthModal = () => {
  const { state, dispatch } = useApp();
  const [isSignUp, setIsSignUp] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    firstName: '',
    lastName: '',
    confirmPassword: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage(null);

    try {
      if (isSignUp) {
        const result = await signUp(formData);
        if (result.success && result.user) {
          dispatch({ type: 'SET_USER', payload: result.user });
          setMessage({ type: 'success', text: 'Account created successfully! Welcome to RDSSEIKO.' });
          
          // Close modal after success
          setTimeout(() => {
            dispatch({ type: 'SET_AUTH_MODAL', payload: false });
            resetForm();
          }, 2000);
        } else {
          setMessage({ type: 'error', text: result.error || 'Registration failed' });
        }
      } else {
        const result = await signIn({ email: formData.email, password: formData.password });
        if (result.success && result.user) {
          dispatch({ type: 'SET_USER', payload: result.user });
          const welcomeMessage = result.user.role === 'admin' 
            ? `Welcome back, Boss ${result.user.firstName}! 👑` 
            : `Welcome back, ${result.user.firstName}!`;
          setMessage({ type: 'success', text: welcomeMessage });
          
          // Close modal after success
          setTimeout(() => {
            dispatch({ type: 'SET_AUTH_MODAL', payload: false });
            resetForm();
          }, 1500);
        } else {
          setMessage({ type: 'error', text: result.error || 'Login failed' });
        }
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'An unexpected error occurred. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      email: '',
      password: '',
      firstName: '',
      lastName: '',
      confirmPassword: ''
    });
    setMessage(null);
    setIsLoading(false);
  };

  const handleModalClose = () => {
    dispatch({ type: 'SET_AUTH_MODAL', payload: false });
    resetForm();
  };

  return (
    <AnimatePresence>
      {state.isAuthModalOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => dispatch({ type: 'SET_AUTH_MODAL', payload: false })}
          >
            {/* Modal */}
            <motion.div
              className="bg-navy border border-gray-800 rounded-xl p-8 max-w-md w-full"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-serif font-bold text-white">
                  {isSignUp ? 'Create Account' : 'Sign In'}
                </h2>
                <button
                  onClick={handleModalClose}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Message */}
              <AnimatePresence>
                {message && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className={`flex items-center space-x-2 p-3 rounded-lg mb-4 ${
                      message.type === 'success' 
                        ? 'bg-green-900/50 border border-green-700 text-green-300' 
                        : 'bg-red-900/50 border border-red-700 text-red-300'
                    }`}
                  >
                    {message.type === 'success' ? (
                      <CheckCircle className="w-5 h-5" />
                    ) : (
                      <AlertCircle className="w-5 h-5" />
                    )}
                    <span className="text-sm">{message.text}</span>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Form */}
              <form onSubmit={handleSubmit} className="space-y-4">
                {isSignUp && (
                  <div className="grid grid-cols-2 gap-4">
                    <input
                      type="text"
                      placeholder="First Name"
                      value={formData.firstName}
                      onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                      className="bg-gray-900 text-white placeholder-gray-400 rounded-lg px-4 py-3 border border-gray-700 focus:border-gold focus:outline-none"
                      required
                    />
                    <input
                      type="text"
                      placeholder="Last Name"
                      value={formData.lastName}
                      onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                      className="bg-gray-900 text-white placeholder-gray-400 rounded-lg px-4 py-3 border border-gray-700 focus:border-gold focus:outline-none"
                      required
                    />
                  </div>
                )}

                <input
                  type="email"
                  placeholder="Email Address"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full bg-gray-900 text-white placeholder-gray-400 rounded-lg px-4 py-3 border border-gray-700 focus:border-gold focus:outline-none"
                  required
                />

                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className="w-full bg-gray-900 text-white placeholder-gray-400 rounded-lg px-4 py-3 pr-12 border border-gray-700 focus:border-gold focus:outline-none"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>

                {isSignUp && (
                  <input
                    type="password"
                    placeholder="Confirm Password"
                    value={formData.confirmPassword}
                    onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                    className="w-full bg-gray-900 text-white placeholder-gray-400 rounded-lg px-4 py-3 border border-gray-700 focus:border-gold focus:outline-none"
                    required
                  />
                )}

                <motion.button
                  type="submit"
                  className="w-full bg-gold text-black py-3 rounded-lg font-semibold hover:bg-yellow-400 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                      <span>{isSignUp ? 'Creating Account...' : 'Signing In...'}</span>
                    </div>
                  ) : (
                    isSignUp ? 'Create Account' : 'Sign In'
                  )}
                </motion.button>
              </form>

              {/* Toggle */}
              <div className="mt-6 text-center">
                <p className="text-gray-400">
                  {isSignUp ? 'Already have an account?' : "Don't have an account?"}
                  <button
                    onClick={() => {
                      setIsSignUp(!isSignUp);
                      setMessage(null);
                    }}
                    className="text-gold hover:text-yellow-400 ml-1 font-semibold"
                    disabled={isLoading}
                  >
                    {isSignUp ? 'Sign In' : 'Sign Up'}
                  </button>
                </p>
              </div>
            </motion.div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default AuthModal;