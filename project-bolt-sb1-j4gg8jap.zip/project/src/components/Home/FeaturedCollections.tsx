import React from 'react';
import { motion } from 'framer-motion';
import ProductCard from '../Product/ProductCard';
import { watches } from '../../data/watches';

function FeaturedCollections() {
  const featuredWatches = watches.slice(0, 6);

  return (
    <section className="py-20 bg-gradient-to-b from-black via-navy to-black relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(212,175,55,0.3)_1px,transparent_0)] bg-[size:60px_60px]" />
      </div>
      
      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-navy/50 via-transparent to-navy/50" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl lg:text-5xl font-serif font-bold text-white mb-6">
            Featured <span className="text-gold">Collections</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Discover our most coveted timepieces, each representing the pinnacle of 
            horological excellence and luxury craftsmanship
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 relative z-10">
          {featuredWatches.map((watch, index) => (
            <motion.div
              key={watch.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <ProductCard watch={watch} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default FeaturedCollections;