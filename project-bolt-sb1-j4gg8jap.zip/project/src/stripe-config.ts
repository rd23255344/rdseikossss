export interface Product {
  priceId: string;
  name: string;
  description: string;
  mode: 'payment' | 'subscription';
}

export const products: Product[] = [
  {
    priceId: 'price_1RxzPxKCH4uiw91JqcYbhJga',
    name: 'SEIKO CUSTOM DAY DATE',
    description: 'Premium custom Seiko watch with day-date functionality, featuring precision movement and elegant design.',
    mode: 'payment'
  }
];

export const getProductByPriceId = (priceId: string): Product | undefined => {
  return products.find(product => product.priceId === priceId);
};

export const getProductById = (id: string): Product | undefined => {
  return products.find(product => product.priceId === id);
};