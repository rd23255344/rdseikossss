// Currency exchange rates (in a real app, these would come from an API)
export const exchangeRates: Record<string, number> = {
  USD: 1,
  EUR: 0.85,
  GBP: 0.73,
  AED: 3.67,
  JPY: 110,
  CAD: 1.25,
  AUD: 1.35
};

export const currencySymbols: Record<string, string> = {
  USD: '$',
  EUR: '€',
  GBP: '£',
  AED: 'د.إ',
  JPY: '¥',
  CAD: 'C$',
  AUD: 'A$'
};

export const formatPrice = (price: number, currency: string): string => {
  const convertedPrice = price * exchangeRates[currency];
  const symbol = currencySymbols[currency];
  
  if (currency === 'JPY') {
    return `${symbol}${Math.round(convertedPrice).toLocaleString()}`;
  }
  
  return `${symbol}${convertedPrice.toLocaleString(undefined, {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  })}`;
};

export const currencies = [
  { code: 'USD', name: 'US Dollar', flag: '🇺🇸' },
  { code: 'EUR', name: 'Euro', flag: '🇪🇺' },
  { code: 'GBP', name: 'British Pound', flag: '🇬🇧' },
  { code: 'AED', name: 'UAE Dirham', flag: '🇦🇪' },
  { code: 'JPY', name: 'Japanese Yen', flag: '🇯🇵' },
  { code: 'CAD', name: 'Canadian Dollar', flag: '🇨🇦' },
  { code: 'AUD', name: 'Australian Dollar', flag: '🇦🇺' }
];