import { User } from '../types';
import { sendSignUpNotificationFallback } from './emailService';

// Boss/Owner account credentials
const BOSS_CREDENTIALS = {
  email: 'rdisking@outlook.com',
  password: '123'
};

// Mock user database (in production, this would be a real database)
let users: User[] = [
  {
    id: 'boss-001',
    email: 'rdisking@outlook.com',
    firstName: 'Boss',
    lastName: 'Owner',
    wishlist: [],
    orders: [],
    role: 'admin'
  }
];

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface SignUpData {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  confirmPassword: string;
}

export const signUp = async (data: SignUpData): Promise<{ success: boolean; user?: User; error?: string }> => {
  try {
    // Validate input
    if (!data.firstName || !data.lastName || !data.email || !data.password) {
      return { success: false, error: 'All fields are required' };
    }

    if (data.password !== data.confirmPassword) {
      return { success: false, error: 'Passwords do not match' };
    }

    if (data.password.length < 6) {
      return { success: false, error: 'Password must be at least 6 characters long' };
    }

    // Check if user already exists
    const existingUser = users.find(user => user.email.toLowerCase() === data.email.toLowerCase());
    if (existingUser) {
      return { success: false, error: 'An account with this email already exists' };
    }

    // Create new user
    const newUser: User = {
      id: Date.now().toString(),
      email: data.email,
      firstName: data.firstName,
      lastName: data.lastName,
      wishlist: [],
      orders: [],
      role: 'customer'
    };

    // Add to mock database
    users.push(newUser);

    // Store in localStorage for persistence
    localStorage.setItem('rdsseiko_users', JSON.stringify(users));
    localStorage.setItem('rdsseiko_current_user', JSON.stringify(newUser));

    // Send email notification
    try {
      await sendSignUpNotificationFallback({
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email,
        password: data.password,
        signupDate: new Date().toLocaleString()
      });
    } catch (emailError) {
      console.error('Email notification failed:', emailError);
      // Don't fail registration if email fails
    }

    return { success: true, user: newUser };
  } catch (error) {
    console.error('Sign up error:', error);
    return { success: false, error: 'Registration failed. Please try again.' };
  }
};

export const signIn = async (credentials: LoginCredentials): Promise<{ success: boolean; user?: User; error?: string }> => {
  try {
    // Load users from localStorage
    const storedUsers = localStorage.getItem('rdsseiko_users');
    if (storedUsers) {
      users = JSON.parse(storedUsers);
    }

    // Check boss credentials first
    if (credentials.email.toLowerCase() === BOSS_CREDENTIALS.email.toLowerCase() && 
        credentials.password === BOSS_CREDENTIALS.password) {
      const bossUser = users.find(user => user.email.toLowerCase() === BOSS_CREDENTIALS.email.toLowerCase()) || {
        id: 'boss-001',
        email: 'rdisking@outlook.com',
        firstName: 'Boss',
        lastName: 'Owner',
        wishlist: [],
        orders: [],
        role: 'admin'
      };
      
      localStorage.setItem('rdsseiko_current_user', JSON.stringify(bossUser));
      return { success: true, user: bossUser };
    }

    // Check regular users
    const user = users.find(user => user.email.toLowerCase() === credentials.email.toLowerCase());
    if (!user) {
      return { success: false, error: 'No account found with this email address' };
    }

    // In a real app, you'd verify the password hash
    // For now, we'll simulate password verification
    const storedPassword = localStorage.getItem(`password_${user.id}`);
    if (!storedPassword) {
      return { success: false, error: 'Invalid credentials' };
    }

    // Store current user
    localStorage.setItem('rdsseiko_current_user', JSON.stringify(user));
    
    return { success: true, user };
  } catch (error) {
    console.error('Sign in error:', error);
    return { success: false, error: 'Login failed. Please try again.' };
  }
};

export const signOut = (): void => {
  localStorage.removeItem('rdsseiko_current_user');
};

export const getCurrentUser = (): User | null => {
  try {
    const storedUser = localStorage.getItem('rdsseiko_current_user');
    return storedUser ? JSON.parse(storedUser) : null;
  } catch (error) {
    console.error('Error getting current user:', error);
    return null;
  }
};

// Initialize users from localStorage on app start
export const initializeAuth = (): User | null => {
  try {
    const storedUsers = localStorage.getItem('rdsseiko_users');
    if (storedUsers) {
      users = JSON.parse(storedUsers);
    }
    return getCurrentUser();
  } catch (error) {
    console.error('Error initializing auth:', error);
    return null;
  }
};