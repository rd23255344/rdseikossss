import emailjs from 'emailjs-com';

// EmailJS configuration
const EMAILJS_SERVICE_ID = 'service_rdsseiko';
const EMAILJS_TEMPLATE_ID = 'template_signup';
const EMAILJS_PUBLIC_KEY = 'your_public_key_here';

export interface SignUpData {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  signupDate: string;
}

export const sendSignUpNotification = async (signUpData: SignUpData): Promise<boolean> => {
  try {
    // Initialize EmailJS (you'll need to set up your EmailJS account)
    emailjs.init(EMAILJS_PUBLIC_KEY);

    const templateParams = {
      to_email: 'musa20100@outlook.com',
      from_name: 'RDSSEIKO Website',
      user_first_name: signUpData.firstName,
      user_last_name: signUpData.lastName,
      user_email: signUpData.email,
      signup_date: signUpData.signupDate,
      message: `New user registration:
      
Name: ${signUpData.firstName} ${signUpData.lastName}
Email: ${signUpData.email}
Registration Date: ${signUpData.signupDate}
      
This user has successfully registered on the RDSSEIKO website.`
    };

    const response = await emailjs.send(
      EMAILJS_SERVICE_ID,
      EMAILJS_TEMPLATE_ID,
      templateParams
    );

    console.log('Email sent successfully:', response);
    return true;
  } catch (error) {
    console.error('Failed to send email:', error);
    // Don't block registration if email fails
    return false;
  }
};

// Fallback email sending using a simple API call
export const sendSignUpNotificationFallback = async (signUpData: SignUpData): Promise<boolean> => {
  try {
    // This is a mock implementation - in production you'd use your backend API
    const emailData = {
      to: 'musa20100@outlook.com',
      subject: 'New RDSSEIKO User Registration',
      body: `New user registration:
      
Name: ${signUpData.firstName} ${signUpData.lastName}
Email: ${signUpData.email}
Registration Date: ${signUpData.signupDate}

This user has successfully registered on the RDSSEIKO website.`
    };

    console.log('Would send email:', emailData);
    return true;
  } catch (error) {
    console.error('Failed to send fallback email:', error);
    return false;
  }
};