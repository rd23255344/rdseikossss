export interface Watch {
  id: string;
  name: string;
  brand: string;
  price: number;
  originalPrice?: number;
  image: string;
  images: string[];
  category: 'mens';
  collection: string;
  description: string;
  specifications: {
    movement: string;
    caseMaterial: string;
    diameter: string;
    thickness: string;
    glass: string;
    luminova: string;
    crown: string;
    wristSize: string;
    lugs: string;
    bracelet: string;
    caseBack: string;
    waterResistance: string;
    dayDateFunction: string;
    warranty: string;
  };
  rating: number;
  reviewCount: number;
  inStock: boolean;
  isNew?: boolean;
  isBestseller?: boolean;
}

export interface CartItem {
  watch: Watch;
  quantity: number;
}

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  wishlist: string[];
  orders: Order[];
  role?: 'customer' | 'admin';
}

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered';
  date: string;
  trackingNumber?: string;
}

export interface Review {
  id: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
  verified: boolean;
}