import { Watch } from '../types';
import { products } from '../stripe-config';

// Get products from localStorage or use default
const getProducts = (): Watch[] => {
  if (typeof window !== 'undefined') {
    const storedProducts = localStorage.getItem('rdsseiko_products');
    if (storedProducts) {
      return JSON.parse(storedProducts);
    }
  }
  return defaultWatches;
};

const defaultWatches: Watch[] = [
  {
    id: 'prod_StmzA2G66Xnhcj',
    name: 'SEIKO CUSTOM DAY DATE',
    brand: 'RDSSEIKO',
    price: 120,
    image: '/seiko-mod-day-date-black-arabic-watch-wristwatch-998.webp',
    images: [
      '/seiko-mod-day-date-black-arabic-watch-wristwatch-998.webp',
      '/sb024.png'
    ],
    category: 'mens',
    collection: 'Custom Collection',
    description: 'Premium custom Seiko watch with day-date functionality, featuring precision movement and elegant design. This exceptional timepiece combines traditional craftsmanship with modern aesthetics.',
    specifications: {
      movement: 'Miyota 8285 automatic movement',
      caseMaterial: '904L stainless steel',
      diameter: '39mm (excluding the crown)',
      thickness: '12mm',
      glass: 'Sapphire, anti-scratch with anti-reflective treatment',
      luminova: 'BGW9 Super-LumiNova',
      crown: 'Screw-down crown',
      wristSize: '14.5cm to 22cm (adjustable bracelet)',
      lugs: '20mm lug width',
      bracelet: '904L stainless steel with security clasp',
      caseBack: 'Exhibition crystal caseback',
      waterResistance: '3 ATM',
      dayDateFunction: 'Yes',
      warranty: '6 Month Workmanship Warranty'
    },
    rating: 5.0,
    reviewCount: 89,
    inStock: true,
    isNew: true,
    isBestseller: true
  }
];

export const watches: Watch[] = getProducts();

// Get the Stripe product configuration for a watch
export const getStripeProduct = (watchId: string) => {
  return products.find(product => product.priceId === watchId);
};